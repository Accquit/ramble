# Fantasy Casino Development Todos

## Setup
- [x] Initialize Next.js project with Shadcn UI
- [x] Install necessary dependencies
- [x] Configure theme and color scheme
- [x] Create project structure

## Core Pages and Components
- [x] Create header/navbar component
- [x] Create footer component
- [x] Design homepage
- [x] Create user context for auth/currency
- [x] Create auth pages (login/register)
- [x] Create games page
- [x] Create profile page
- [x] Create leaderboard page

## Games Implementation
- [x] Create slot machine game
- [x] Create dice game
- [x] Create blackjack game
- [x] Update header to show user data when logged in

## Future Enhancements
- [ ] Add sound effects to games
- [ ] Implement achievements system
- [ ] Create more game variations
- [ ] Add daily rewards
- [ ] Implement user settings (avatar, username change)
- [ ] Add social features (friend lists, challenges)
- [ ] Create a tournament system

## Core Features
- [ ] Create homepage/landing page
- [ ] Design navigation system
- [ ] Implement auth system with fake accounts
- [ ] Create virtual currency system
- [ ] Build user dashboard/profile

## Games
- [ ] Create game selection page
- [ ] Implement slot machine game
- [ ] Implement dice game
- [ ] Implement simple card game
- [ ] Add game statistics/history

## UI/UX
- [ ] Design dark theme casino interface
- [ ] Create animated game components
- [ ] Add sound effects
- [ ] Implement responsive design

## Additional Features
- [ ] Add leaderboard
- [ ] Implement achievements
- [ ] Add virtual currency rewards (daily bonus, etc.)
