"use client";

import { ReactNode, useEffect } from "react";
import { UserProvider } from "@/contexts/UserContext";

export default function ClientBody({
  children,
}: {
  children: ReactNode;
}) {
  // Remove any extension-added classes during hydration
  useEffect(() => {
    // This runs only on the client after hydration
    document.body.className = "antialiased";
  }, []);

  return (
    <UserProvider>
      <div className="antialiased">{children}</div>
    </UserProvider>
  );
}
