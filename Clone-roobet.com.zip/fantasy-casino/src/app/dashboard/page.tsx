"use client";

import { useState, useEffect } from "react";
import { useRouter } from "next/navigation";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useUser } from "@/lib/user-context";
import { useToast } from "@/components/ui/use-toast";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Copy, Check, ArrowDown, ArrowUp, Clock, Wallet, CreditCard, AlertCircle } from "lucide-react";

// Mock crypto addresses
const addresses = {
  btc: "bc1qxy2kgdygjrsqtzq2n0yrf2493p83kkfjhx0wlh",
  eth: "0x71C7656EC7ab88b098defB751B7401B5f6d8976F",
  ltc: "LTC123456789abcdefABCDEF123456789abcdefABCD",
  doge: "D8vjcD88Kz9LZmkZUbtNJFZnhUmAh6squA",
  xrp: "rEQQNvfQwHvKhRYiGHEmZhRxVw3P5RMczP",
}

// Crypto options with icons
const cryptoOptions = [
  { id: "btc", name: "Bitcoin", symbol: "BTC", icon: "₿", address: addresses.btc },
  { id: "eth", name: "Ethereum", symbol: "ETH", icon: "Ξ", address: addresses.eth },
  { id: "ltc", name: "Litecoin", symbol: "LTC", icon: "Ł", address: addresses.ltc },
  { id: "doge", name: "Dogecoin", symbol: "DOGE", icon: "Ð", address: addresses.doge },
  { id: "xrp", name: "Ripple", symbol: "XRP", icon: "✕", address: addresses.xrp },
];

// Mock transaction history
const transactionHistory = [
  { id: 1, type: "deposit", amount: 0.05, currency: "BTC", status: "completed", date: "2025-05-21" },
  { id: 2, type: "withdrawal", amount: 0.03, currency: "BTC", status: "completed", date: "2025-05-18" },
  { id: 3, type: "deposit", amount: 1.2, currency: "ETH", status: "completed", date: "2025-05-15" },
  { id: 4, type: "withdrawal", amount: 0.8, currency: "ETH", status: "pending", date: "2025-05-22" },
  { id: 5, type: "deposit", amount: 500, currency: "DOGE", status: "completed", date: "2025-05-10" },
];

export default function DashboardPage() {
  const { user, updateBalance } = useUser();
  const { toast } = useToast();
  const router = useRouter();

  const [selectedCrypto, setSelectedCrypto] = useState(cryptoOptions[0]);
  const [depositAmount, setDepositAmount] = useState("");
  const [withdrawAmount, setWithdrawAmount] = useState("");
  const [withdrawAddress, setWithdrawAddress] = useState("");
  const [isCopied, setIsCopied] = useState(false);
  const [processingDeposit, setProcessingDeposit] = useState(false);
  const [processingWithdrawal, setProcessingWithdrawal] = useState(false);

  // Exchange rates (1 coin = x crypto)
  const exchangeRates = {
    btc: 0.00001,
    eth: 0.0001,
    ltc: 0.001,
    doge: 1,
    xrp: 0.5
  };

  // Check if user is logged in
  useEffect(() => {
    if (user && !user.isLoggedIn) {
      toast({
        title: "Login Required",
        description: "Please login to access your dashboard.",
        variant: "destructive",
      });
      router.push("/auth/login");
    }
  }, [user, router, toast]);

  // Copy address to clipboard
  const copyAddress = () => {
    navigator.clipboard.writeText(selectedCrypto.address);
    setIsCopied(true);

    toast({
      title: "Address copied!",
      description: "Crypto address copied to clipboard.",
    });

    setTimeout(() => {
      setIsCopied(false);
    }, 2000);
  };

  // Handle deposit confirmation (FAKE)
  const handleConfirmDeposit = () => {
    if (!depositAmount || isNaN(parseFloat(depositAmount)) || parseFloat(depositAmount) <= 0) {
      toast({
        title: "Invalid amount",
        description: "Please enter a valid deposit amount.",
        variant: "destructive",
      });
      return;
    }

    setProcessingDeposit(true);

    // Convert crypto to coins (simulated)
    const cryptoAmount = parseFloat(depositAmount);
    const coinAmount = Math.floor(cryptoAmount / exchangeRates[selectedCrypto.id as keyof typeof exchangeRates] * 1);

    // Simulate network delay
    setTimeout(() => {
      updateBalance(coinAmount);

      toast({
        title: "Deposit successful!",
        description: `${depositAmount} ${selectedCrypto.symbol} converted to ${coinAmount} coins.`,
      });

      setDepositAmount("");
      setProcessingDeposit(false);
    }, 2000);
  };

  // Handle withdrawal (FAKE)
  const handleWithdraw = () => {
    if (!withdrawAmount || isNaN(parseFloat(withdrawAmount)) || parseFloat(withdrawAmount) <= 0) {
      toast({
        title: "Invalid amount",
        description: "Please enter a valid withdrawal amount.",
        variant: "destructive",
      });
      return;
    }

    if (!withdrawAddress) {
      toast({
        title: "Missing address",
        description: "Please enter a withdrawal address.",
        variant: "destructive",
      });
      return;
    }

    // Convert coins to crypto
    const coinAmount = parseFloat(withdrawAmount);
    const cryptoAmount = coinAmount * exchangeRates[selectedCrypto.id as keyof typeof exchangeRates];

    // Check if user has enough balance
    if (!user || user.balance < coinAmount) {
      toast({
        title: "Insufficient balance",
        description: "You don't have enough coins for this withdrawal.",
        variant: "destructive",
      });
      return;
    }

    setProcessingWithdrawal(true);

    // Simulate network delay
    setTimeout(() => {
      updateBalance(-coinAmount);

      toast({
        title: "Withdrawal initiated",
        description: `${cryptoAmount.toFixed(8)} ${selectedCrypto.symbol} will be sent to your wallet shortly.`,
      });

      setWithdrawAmount("");
      setWithdrawAddress("");
      setProcessingWithdrawal(false);
    }, 2000);
  };

  if (!user || !user.isLoggedIn) {
    return <div className="container py-20 text-center">Loading...</div>;
  }

  return (
    <div className="container py-10">
      <div className="mb-10">
        <h1 className="text-4xl font-bold tracking-tight neon-text mb-2">Dashboard</h1>
        <p className="text-xl text-muted-foreground">
          Manage your account, deposits and withdrawals
        </p>
      </div>

      <div className="grid gap-6 md:grid-cols-6">
        {/* Sidebar */}
        <div className="md:col-span-2">
          <Card className="casino-card mb-6">
            <CardHeader className="pb-2">
              <CardTitle className="text-xl">Account Overview</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center gap-4">
                <Avatar className="h-16 w-16">
                  <AvatarImage src={user.avatar} alt={user.username} />
                  <AvatarFallback>{user.username.charAt(0).toUpperCase()}</AvatarFallback>
                </Avatar>
                <div>
                  <h3 className="font-medium text-lg">{user.username}</h3>
                  <p className="text-sm text-muted-foreground">User since {user.joinedAt.toLocaleDateString()}</p>
                </div>
              </div>

              <div className="rounded-lg bg-secondary/50 p-4">
                <div className="flex justify-between items-center mb-2">
                  <span className="text-sm text-muted-foreground">Balance</span>
                  <Button variant="outline" size="sm" asChild>
                    <a href="/games">Play Games</a>
                  </Button>
                </div>
                <div className="text-3xl font-bold text-gold">
                  {user.balance.toLocaleString()} <span className="text-xs text-muted-foreground align-top">COINS</span>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="rounded-lg bg-muted/30 p-3">
                  <div className="text-sm text-muted-foreground mb-1">Total Wagered</div>
                  <div className="font-medium">{(user.winnings + user.losses).toLocaleString()}</div>
                </div>
                <div className="rounded-lg bg-muted/30 p-3">
                  <div className="text-sm text-muted-foreground mb-1">Games Played</div>
                  <div className="font-medium">{user.gamesPlayed}</div>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="casino-card">
            <CardHeader className="pb-2">
              <CardTitle className="text-xl">Quick Links</CardTitle>
            </CardHeader>
            <CardContent className="space-y-2">
              <Button variant="outline" className="w-full justify-start" asChild>
                <a href="/profile">
                  <Avatar className="h-5 w-5 mr-2">
                    <AvatarFallback>{user.username.charAt(0).toUpperCase()}</AvatarFallback>
                  </Avatar>
                  Profile
                </a>
              </Button>
              <Button variant="outline" className="w-full justify-start" asChild>
                <a href="/games">
                  <span className="mr-2">🎮</span>
                  Games
                </a>
              </Button>
              <Button variant="outline" className="w-full justify-start" asChild>
                <a href="/leaderboard">
                  <span className="mr-2">🏆</span>
                  Leaderboard
                </a>
              </Button>
            </CardContent>
          </Card>
        </div>

        {/* Main Content */}
        <div className="md:col-span-4 space-y-6">
          <Tabs defaultValue="deposit" className="w-full">
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="deposit">Deposit</TabsTrigger>
              <TabsTrigger value="withdrawal">Withdrawal</TabsTrigger>
            </TabsList>

            {/* Deposit Tab */}
            <TabsContent value="deposit" className="space-y-4">
              <Card className="casino-card">
                <CardHeader>
                  <CardTitle>Deposit Crypto</CardTitle>
                  <CardDescription>
                    Add funds to your account using cryptocurrency
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-2 md:grid-cols-5 gap-2">
                    {cryptoOptions.map((crypto) => (
                      <Button
                        key={crypto.id}
                        variant={selectedCrypto.id === crypto.id ? "default" : "outline"}
                        className="flex flex-col h-20 items-center justify-center"
                        onClick={() => setSelectedCrypto(crypto)}
                      >
                        <span className="text-xl font-medium">{crypto.icon}</span>
                        <span className="text-xs">{crypto.symbol}</span>
                      </Button>
                    ))}
                  </div>

                  <div className="p-4 rounded-md bg-muted/20 space-y-4">
                    <div className="text-center">
                      <p className="text-sm text-muted-foreground mb-2">Send only {selectedCrypto.name} to this address:</p>
                      <div className="w-full p-3 bg-secondary/40 rounded-md flex items-center justify-between">
                        <code className="text-xs md:text-sm overflow-auto">{selectedCrypto.address}</code>
                        <Button size="sm" variant="ghost" onClick={copyAddress}>
                          {isCopied ? <Check className="h-4 w-4" /> : <Copy className="h-4 w-4" />}
                        </Button>
                      </div>
                    </div>

                    <div className="flex flex-col space-y-1.5">
                      <Label htmlFor="depositAmount">Amount ({selectedCrypto.symbol})</Label>
                      <div className="flex">
                        <Input
                          id="depositAmount"
                          placeholder={`Enter ${selectedCrypto.symbol} amount`}
                          value={depositAmount}
                          onChange={(e) => setDepositAmount(e.target.value)}
                        />
                        <Button
                          className="ml-2"
                          onClick={handleConfirmDeposit}
                          disabled={processingDeposit}
                        >
                          {processingDeposit ? "Processing..." : "Confirm"}
                        </Button>
                      </div>
                      <div className="text-xs text-muted-foreground mt-1">
                        {depositAmount && !isNaN(parseFloat(depositAmount)) && parseFloat(depositAmount) > 0 ? (
                          <span>
                            You'll receive approximately {Math.floor(parseFloat(depositAmount) / exchangeRates[selectedCrypto.id as keyof typeof exchangeRates])} coins
                          </span>
                        ) : null}
                      </div>
                    </div>
                  </div>

                  <div className="rounded-md border border-amber-400/20 bg-amber-400/10 p-3">
                    <div className="flex items-start gap-2">
                      <AlertCircle className="h-5 w-5 text-amber-400 mt-0.5" />
                      <div>
                        <h4 className="text-sm font-medium text-amber-400">Important Note</h4>
                        <p className="text-xs text-muted-foreground">
                          This is a simulated deposit system. No actual cryptocurrency transactions occur.
                          This is for demonstration purposes only.
                        </p>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            {/* Withdrawal Tab */}
            <TabsContent value="withdrawal" className="space-y-4">
              <Card className="casino-card">
                <CardHeader>
                  <CardTitle>Withdraw Crypto</CardTitle>
                  <CardDescription>
                    Convert your coins to cryptocurrency
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-2 md:grid-cols-5 gap-2">
                    {cryptoOptions.map((crypto) => (
                      <Button
                        key={crypto.id}
                        variant={selectedCrypto.id === crypto.id ? "default" : "outline"}
                        className="flex flex-col h-20 items-center justify-center"
                        onClick={() => setSelectedCrypto(crypto)}
                      >
                        <span className="text-xl font-medium">{crypto.icon}</span>
                        <span className="text-xs">{crypto.symbol}</span>
                      </Button>
                    ))}
                  </div>

                  <div className="space-y-4">
                    <div className="flex flex-col space-y-1.5">
                      <Label htmlFor="withdrawAmount">Amount (Coins)</Label>
                      <Input
                        id="withdrawAmount"
                        placeholder="Enter coin amount"
                        value={withdrawAmount}
                        onChange={(e) => setWithdrawAmount(e.target.value)}
                      />
                      <div className="text-xs text-muted-foreground">
                        {withdrawAmount && !isNaN(parseFloat(withdrawAmount)) && parseFloat(withdrawAmount) > 0 ? (
                          <span>
                            You'll receive approximately {(parseFloat(withdrawAmount) * exchangeRates[selectedCrypto.id as keyof typeof exchangeRates]).toFixed(8)} {selectedCrypto.symbol}
                          </span>
                        ) : null}
                      </div>
                    </div>

                    <div className="flex flex-col space-y-1.5">
                      <Label htmlFor="withdrawAddress">{selectedCrypto.name} Address</Label>
                      <Input
                        id="withdrawAddress"
                        placeholder={`Enter your ${selectedCrypto.name} wallet address`}
                        value={withdrawAddress}
                        onChange={(e) => setWithdrawAddress(e.target.value)}
                      />
                    </div>

                    <Button
                      className="w-full"
                      onClick={handleWithdraw}
                      disabled={processingWithdrawal}
                    >
                      {processingWithdrawal ? "Processing..." : "Withdraw"}
                    </Button>
                  </div>

                  <div className="rounded-md border border-amber-400/20 bg-amber-400/10 p-3">
                    <div className="flex items-start gap-2">
                      <AlertCircle className="h-5 w-5 text-amber-400 mt-0.5" />
                      <div>
                        <h4 className="text-sm font-medium text-amber-400">Important Note</h4>
                        <p className="text-xs text-muted-foreground">
                          This is a simulated withdrawal system. No actual cryptocurrency transactions occur.
                          This is for demonstration purposes only.
                        </p>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>

          {/* Transaction History */}
          <Card className="casino-card">
            <CardHeader>
              <CardTitle>Transaction History</CardTitle>
              <CardDescription>
                Recent deposits and withdrawals
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="rounded-md border">
                <div className="grid grid-cols-5 p-3 text-xs font-medium border-b">
                  <div>Type</div>
                  <div>Amount</div>
                  <div>Currency</div>
                  <div>Status</div>
                  <div>Date</div>
                </div>
                <div className="divide-y">
                  {transactionHistory.map((tx) => (
                    <div key={tx.id} className="grid grid-cols-5 p-3 text-sm">
                      <div className="flex items-center">
                        {tx.type === "deposit" ? (
                          <ArrowDown className="h-4 w-4 mr-1 text-success" />
                        ) : (
                          <ArrowUp className="h-4 w-4 mr-1 text-primary" />
                        )}
                        {tx.type === "deposit" ? "Deposit" : "Withdrawal"}
                      </div>
                      <div>{tx.amount}</div>
                      <div>{tx.currency}</div>
                      <div>
                        {tx.status === "completed" ? (
                          <span className="flex items-center text-success">
                            <Check className="h-3 w-3 mr-1" />
                            Completed
                          </span>
                        ) : (
                          <span className="flex items-center text-amber-400">
                            <Clock className="h-3 w-3 mr-1" />
                            Pending
                          </span>
                        )}
                      </div>
                      <div>{tx.date}</div>
                    </div>
                  ))}
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
