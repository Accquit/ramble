"use client";

import { useState, useEffect } from "react";
import { useRouter } from "next/navigation";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useVip, VIP_TIERS, VipTier, VipTierKey } from "@/lib/vip-context";
import { useUser } from "@/lib/user-context";
import { useToast } from "@/components/ui/use-toast";
import { Check, ChevronRight, Crown, Gift, Star, Zap } from "lucide-react";

export default function VipPage() {
  const { user } = useUser();
  const { currentTier, nextTier, progress, totalWagered, claimWeeklyBonus, canClaimWeeklyBonus } = useVip();
  const { toast } = useToast();
  const router = useRouter();

  // Sorted tiers for display
  const tiers = Object.entries(VIP_TIERS)
    .map(([key, tier]) => ({ key, ...tier }))
    .sort((a, b) => a.level - b.level);

  // Check if user is logged in
  useEffect(() => {
    if (user && !user.isLoggedIn) {
      toast({
        title: "Login Required",
        description: "Please login to view your VIP status.",
        variant: "destructive",
      });
      router.push("/auth/login");
    }
  }, [user, router, toast]);

  // Handle claiming weekly bonus
  const handleClaimBonus = () => {
    claimWeeklyBonus();
    toast({
      title: "Bonus Claimed!",
      description: `You've received ${currentTier.weeklyBonus} coins as your weekly VIP bonus.`,
    });
  };

  if (!user || !user.isLoggedIn) {
    return <div className="container py-20 text-center">Loading...</div>;
  }

  return (
    <div className="container py-10">
      <div className="mb-10">
        <h1 className="text-4xl font-bold tracking-tight neon-text mb-2">VIP Program</h1>
        <p className="text-xl text-muted-foreground">
          Enjoy exclusive benefits and boosted odds as you climb our VIP tiers
        </p>
      </div>

      {/* Current VIP Status */}
      <div className="mb-10">
        <Card className="casino-card overflow-hidden">
          <div className={`h-2 ${currentTier.colorClass} bg-opacity-50`} style={{ width: `${progress}%` }}></div>
          <CardHeader>
            <div className="flex justify-between items-center">
              <div>
                <CardTitle className="flex items-center gap-2">
                  <Crown className={`h-5 w-5 ${currentTier.colorClass}`} />
                  <span className={currentTier.colorClass}>
                    {currentTier.name} VIP
                  </span>
                  <span className={`ml-2 text-xs px-2 py-0.5 rounded-full ${currentTier.badgeClass}`}>
                    Level {currentTier.level}
                  </span>
                </CardTitle>
                <CardDescription>{currentTier.description}</CardDescription>
              </div>

              {canClaimWeeklyBonus && currentTier.level > 0 && (
                <Button onClick={handleClaimBonus} className="flex items-center gap-2">
                  <Gift className="h-4 w-4" />
                  Claim {currentTier.weeklyBonus} Coins
                </Button>
              )}
            </div>
          </CardHeader>

          <CardContent className="space-y-4">
            <div>
              <div className="flex justify-between mb-1 text-sm">
                <span>Progress to {nextTier ? nextTier.name : "Max Level"}</span>
                <span>{Math.floor(progress)}%</span>
              </div>
              <div className="w-full h-2 bg-muted rounded-full overflow-hidden">
                <div
                  className={`h-full ${currentTier.colorClass}`}
                  style={{ width: `${progress}%`, opacity: 0.7 }}
                ></div>
              </div>

              <div className="mt-2 text-sm text-muted-foreground">
                {nextTier ? (
                  <>
                    Total Wagered: {totalWagered.toLocaleString()} / {nextTier.requiredWager.toLocaleString()} coins
                    <span className="block mt-1">
                      Wager {(nextTier.requiredWager - totalWagered).toLocaleString()} more coins to reach {nextTier.name}
                    </span>
                  </>
                ) : (
                  <>
                    Total Wagered: {totalWagered.toLocaleString()} coins
                    <span className="block mt-1">
                      You've reached the highest VIP tier!
                    </span>
                  </>
                )}
              </div>
            </div>

            {/* Current Benefits */}
            <div className="mt-6">
              <h3 className="text-lg font-medium mb-3">Your Current Benefits</h3>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="bg-muted/20 p-4 rounded-lg">
                  <div className="flex items-center gap-2 mb-2">
                    <Zap className={`h-4 w-4 ${currentTier.colorClass}`} />
                    <span className="font-medium">Odds Boost</span>
                  </div>
                  <div className={`text-2xl font-bold ${currentTier.colorClass}`}>
                    +{currentTier.appearingOddsBoost}%
                  </div>
                  <p className="text-xs text-muted-foreground mt-1">
                    Improved winning chances on all games
                  </p>
                </div>

                <div className="bg-muted/20 p-4 rounded-lg">
                  <div className="flex items-center gap-2 mb-2">
                    <Gift className={`h-4 w-4 ${currentTier.colorClass}`} />
                    <span className="font-medium">Weekly Bonus</span>
                  </div>
                  <div className={`text-2xl font-bold ${currentTier.colorClass}`}>
                    {currentTier.weeklyBonus.toLocaleString()}
                  </div>
                  <p className="text-xs text-muted-foreground mt-1">
                    Free coins every week
                  </p>
                </div>

                <div className="bg-muted/20 p-4 rounded-lg">
                  <div className="flex items-center gap-2 mb-2">
                    <Star className={`h-4 w-4 ${currentTier.colorClass}`} />
                    <span className="font-medium">Deposit Bonus</span>
                  </div>
                  <div className={`text-2xl font-bold ${currentTier.colorClass}`}>
                    {currentTier.depositBonus}%
                  </div>
                  <p className="text-xs text-muted-foreground mt-1">
                    Extra coins on every deposit
                  </p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* VIP Tiers Table */}
      <div className="mb-10">
        <Card className="casino-card">
          <CardHeader>
            <CardTitle>VIP Tiers & Benefits</CardTitle>
            <CardDescription>
              Play more to unlock higher VIP levels and better rewards
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b">
                    <th className="text-left py-3 px-4">Tier</th>
                    <th className="text-left py-3 px-4">Required Wager</th>
                    <th className="text-left py-3 px-4">Odds Boost</th>
                    <th className="text-left py-3 px-4">Weekly Bonus</th>
                    <th className="text-left py-3 px-4">Deposit Bonus</th>
                    <th className="text-left py-3 px-4">Rakeback</th>
                  </tr>
                </thead>
                <tbody>
                  {tiers.map((tier) => (
                    <tr
                      key={tier.key}
                      className={`border-b ${currentTier.level === tier.level ? 'bg-primary/5' : ''}`}
                    >
                      <td className="py-3 px-4">
                        <div className="flex items-center gap-2">
                          {currentTier.level === tier.level && (
                            <Check className="h-4 w-4 text-success" />
                          )}
                          <span className={`font-medium ${tier.colorClass}`}>
                            {tier.name}
                          </span>
                        </div>
                      </td>
                      <td className="py-3 px-4">
                        {tier.level === 0 ? 'None' : `${tier.requiredWager.toLocaleString()} coins`}
                      </td>
                      <td className="py-3 px-4">
                        {tier.appearingOddsBoost > 0 ? `+${tier.appearingOddsBoost}%` : 'None'}
                      </td>
                      <td className="py-3 px-4">
                        {tier.weeklyBonus > 0 ? `${tier.weeklyBonus.toLocaleString()} coins` : 'None'}
                      </td>
                      <td className="py-3 px-4">
                        {tier.depositBonus > 0 ? `${tier.depositBonus}%` : 'None'}
                      </td>
                      <td className="py-3 px-4">
                        {tier.rakeback > 0 ? `${tier.rakeback}%` : 'None'}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* VIP FAQ */}
      <Card className="casino-card">
        <CardHeader>
          <CardTitle>VIP Program FAQ</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <h3 className="font-medium mb-1">How do I increase my VIP level?</h3>
            <p className="text-sm text-muted-foreground">
              Your VIP level increases automatically as you play games. The total amount you wager determines your VIP tier.
            </p>
          </div>

          <div>
            <h3 className="font-medium mb-1">What is Odds Boost?</h3>
            <p className="text-sm text-muted-foreground">
              Odds Boost increases your chances of winning on all games proportional to your VIP level.
              For example, at Diamond level, you'll have a 15% higher chance of winning than standard players.
            </p>
          </div>

          <div>
            <h3 className="font-medium mb-1">How do Weekly Bonuses work?</h3>
            <p className="text-sm text-muted-foreground">
              Once you reach Bronze level, you'll be eligible for a weekly bonus. The bonus amount increases with each VIP tier.
              You can claim your bonus once every 7 days.
            </p>
          </div>

          <div>
            <h3 className="font-medium mb-1">What is Rakeback?</h3>
            <p className="text-sm text-muted-foreground">
              Rakeback returns a percentage of your losses back to you. The higher your VIP level, the more rakeback you'll receive.
            </p>
          </div>

          <div>
            <h3 className="font-medium mb-1">Can I lose my VIP status?</h3>
            <p className="text-sm text-muted-foreground">
              No, once you've reached a VIP level, you'll maintain that level permanently.
            </p>
          </div>
        </CardContent>

        <CardFooter>
          <Button asChild>
            <a href="/games">Start Playing to Increase VIP Level</a>
          </Button>
        </CardFooter>
      </Card>
    </div>
  );
}
