"use client";

import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { useUser } from "@/lib/user-context";
import { useVip } from "@/lib/vip-context";
import { useToast } from "@/components/ui/use-toast";
import { useRouter } from "next/navigation";
import { Crown, Info } from "lucide-react";

// Slot machine symbols
const symbols = ["🍒", "🍋", "🍊", "🍇", "🍉", "💎", "7️⃣", "🎰"];

// Payouts for different combinations
const payouts = {
  "🍒🍒🍒": 3,
  "🍋🍋🍋": 4,
  "🍊🍊🍊": 5,
  "🍇🍇🍇": 6,
  "🍉🍉🍉": 8,
  "💎💎💎": 10,
  "7️⃣7️⃣7️⃣": 20,
  "🎰🎰🎰": 50,
  // Two of the same symbols
  "🍒🍒": 1.5,
  "🍋🍋": 1.5,
  "🍊🍊": 2,
  "🍇🍇": 2,
  "🍉🍉": 2.5,
  "💎💎": 3,
  "7️⃣7️⃣": 5,
  "🎰🎰": 10,
};

// Betting options
const betOptions = [10, 25, 50, 100, 250, 500, 1000];

export default function SlotsPage() {
  const { user, updateBalance } = useUser();
  const { currentTier } = useVip();
  const { toast } = useToast();
  const router = useRouter();

  const [reels, setReels] = useState<string[]>(["🎰", "🎰", "🎰"]);
  const [spinning, setSpinning] = useState<boolean>(false);
  const [betAmount, setBetAmount] = useState<number>(10);
  const [winAmount, setWinAmount] = useState<number | null>(null);
  const [autoPlay, setAutoPlay] = useState<boolean>(false);
  const [spinsRemaining, setSpinsRemaining] = useState<number>(0);
  const [showVipInfo, setShowVipInfo] = useState<boolean>(false);

  // Check if user is logged in
  useEffect(() => {
    if (user && !user.isLoggedIn) {
      toast({
        title: "Login Required",
        description: "Please login to play games.",
        variant: "destructive",
      });
      router.push("/auth/login");
    }
  }, [user, router, toast]);

  // Auto play function
  useEffect(() => {
    if (autoPlay && spinsRemaining > 0 && !spinning && user && user.balance >= betAmount) {
      const timer = setTimeout(() => {
        handleSpin();
        setSpinsRemaining(prev => prev - 1);

        if (spinsRemaining === 1) {
          setAutoPlay(false);
        }
      }, 1500);

      return () => clearTimeout(timer);
    }
  }, [autoPlay, spinsRemaining, spinning, user, betAmount]);

  // Spin the reels
  const handleSpin = () => {
    if (!user) return;

    if (user.balance < betAmount) {
      toast({
        title: "Insufficient funds",
        description: "You don't have enough coins to place this bet.",
        variant: "destructive",
      });
      return;
    }

    // Deduct bet amount
    updateBalance(-betAmount);

    setSpinning(true);
    setWinAmount(null);

    // Animate spinning by changing symbols rapidly
    let spinInterval: NodeJS.Timeout;
    let spinDuration = 0;

    spinInterval = setInterval(() => {
      setReels([
        symbols[Math.floor(Math.random() * symbols.length)],
        symbols[Math.floor(Math.random() * symbols.length)],
        symbols[Math.floor(Math.random() * symbols.length)],
      ]);

      spinDuration += 100;

      if (spinDuration >= 2000) {
        clearInterval(spinInterval);

        // MODIFIED: Ensure player never wins by generating a losing combination
        // Make sure no two adjacent symbols match
        let finalReels: string[] = [];

        // Use different symbols for each position
        const symbolsSet = [...symbols];
        const shuffled = symbolsSet.sort(() => 0.5 - Math.random());

        // Take the first three different symbols
        finalReels = shuffled.slice(0, 3);

        // If by chance we got a winning combo (3 same or 2 same adjacent), fix it
        if (finalReels[0] === finalReels[1] && finalReels[1] === finalReels[2]) {
          // Replace the middle symbol with something different
          for (const sym of symbols) {
            if (sym !== finalReels[0]) {
              finalReels[1] = sym;
              break;
            }
          }
        } else if (finalReels[0] === finalReels[1] || finalReels[1] === finalReels[2]) {
          // If two adjacent symbols match, change the middle one
          for (const sym of symbols) {
            if (sym !== finalReels[0] && sym !== finalReels[2]) {
              finalReels[1] = sym;
              break;
            }
          }
        }

        setReels(finalReels);
        setSpinning(false);

        // Still call checkWin but we've ensured there's no win
        checkWin(finalReels);
      }
    }, 100);
  };

  // Check if the player has won - will always return 0 now
  const checkWin = (currentReels: string[]) => {
    // The reels are rigged to always lose, so this will always return 0
    // but we keep the function for appearance
    let win = 0;

    // No wins will be triggered, but leaving the logic for show
    if (currentReels[0] === currentReels[1] && currentReels[1] === currentReels[2]) {
      const symbol = currentReels[0];
      const key = `${symbol}${symbol}${symbol}` as keyof typeof payouts;
      if (payouts[key]) {
        win = betAmount * payouts[key];
      }
    }
    else if (
      currentReels[0] === currentReels[1] ||
      currentReels[1] === currentReels[2] ||
      currentReels[0] === currentReels[2]
    ) {
      let matchSymbol = "";

      if (currentReels[0] === currentReels[1]) {
        matchSymbol = currentReels[0];
      } else if (currentReels[1] === currentReels[2]) {
        matchSymbol = currentReels[1];
      } else if (currentReels[0] === currentReels[2]) {
        matchSymbol = currentReels[0];
      }

      const key = `${matchSymbol}${matchSymbol}` as keyof typeof payouts;
      if (payouts[key]) {
        win = betAmount * payouts[key];
      }
    }

    if (win > 0) {
      setWinAmount(win);
      updateBalance(win);

      toast({
        title: "Winner!",
        description: `You won ${win} coins!`,
      });
    }
  };

  // Start auto play
  const startAutoPlay = (spins: number) => {
    setAutoPlay(true);
    setSpinsRemaining(spins);
  };

  // Stop auto play
  const stopAutoPlay = () => {
    setAutoPlay(false);
    setSpinsRemaining(0);
  };

  // Get the VIP boosted payout display (doesn't actually change odds)
  const getDisplayPayout = (originalPayout: number): number => {
    if (currentTier.appearingOddsBoost === 0) return originalPayout;

    // Calculate boosted payout for display only
    const boost = 1 + (currentTier.appearingOddsBoost / 100);
    return parseFloat((originalPayout * boost).toFixed(2));
  };

  if (!user || !user.isLoggedIn) {
    return <div className="container py-20 text-center">Loading...</div>;
  }

  return (
    <div className="container py-10">
      <div className="mb-10 text-center">
        <h1 className="text-4xl font-bold tracking-tight neon-text mb-2">Slot Machine</h1>
        <p className="text-xl text-muted-foreground">
          Spin to win big with our virtual slot machine!
        </p>
      </div>

      <div className="grid gap-6 md:grid-cols-3">
        <div className="md:col-span-2">
          <Card className="casino-card">
            <CardHeader>
              <div className="flex justify-between items-center">
                <CardTitle className="text-center">Slot Machine</CardTitle>
                {currentTier.level > 0 && (
                  <div
                    className={`flex items-center gap-1 ${currentTier.badgeClass} px-2 py-1 rounded-full text-xs cursor-pointer`}
                    onClick={() => setShowVipInfo(!showVipInfo)}
                  >
                    <Crown className="h-3 w-3" />
                    <span>+{currentTier.appearingOddsBoost}% Odds</span>
                    <Info className="h-3 w-3 ml-0.5" />
                  </div>
                )}
              </div>
              <CardDescription className="text-center">
                Match 3 symbols for big wins, or 2 for smaller rewards
              </CardDescription>

              {showVipInfo && (
                <div className="mt-2 p-2 bg-muted/20 rounded-md text-xs">
                  <p className="text-muted-foreground">
                    Your {currentTier.name} VIP status gives you a +{currentTier.appearingOddsBoost}% boost to your winning odds!
                    This applies to all games and increases your chances of winning.
                  </p>
                </div>
              )}
            </CardHeader>
            <CardContent className="flex flex-col items-center">
              {/* Slot Machine Display */}
              <div className="flex justify-center gap-4 my-6">
                {reels.map((symbol, index) => (
                  <div
                    key={index}
                    className={`flex h-32 w-32 items-center justify-center rounded-md border border-border bg-card text-4xl
                    ${spinning ? "animate-pulse" : ""}`}
                  >
                    {symbol}
                  </div>
                ))}
              </div>

              {/* Win Display */}
              {winAmount !== null && (
                <div className="my-4 text-center">
                  <div className="text-2xl font-bold text-gold">
                    You won {winAmount} coins!
                  </div>
                </div>
              )}

              {/* Betting Controls */}
              <div className="w-full max-w-md mt-4">
                <div className="mb-4">
                  <div className="text-sm text-muted-foreground mb-2">Select Bet Amount:</div>
                  <div className="flex flex-wrap gap-2 justify-center">
                    {betOptions.map((bet) => (
                      <Button
                        key={bet}
                        variant={betAmount === bet ? "default" : "outline"}
                        size="sm"
                        onClick={() => setBetAmount(bet)}
                        disabled={spinning || user.balance < bet}
                      >
                        {bet}
                      </Button>
                    ))}
                  </div>
                </div>

                {/* Spin Button */}
                <Button
                  className="w-full h-14 text-lg neon-border"
                  disabled={spinning || user.balance < betAmount || autoPlay}
                  onClick={handleSpin}
                >
                  {spinning ? "Spinning..." : `Spin (${betAmount} coins)`}
                </Button>

                {/* Auto Play Controls */}
                <div className="grid grid-cols-3 gap-2 mt-4">
                  <Button
                    variant="outline"
                    disabled={spinning || user.balance < betAmount || autoPlay}
                    onClick={() => startAutoPlay(5)}
                  >
                    Auto x5
                  </Button>
                  <Button
                    variant="outline"
                    disabled={spinning || user.balance < betAmount || autoPlay}
                    onClick={() => startAutoPlay(10)}
                  >
                    Auto x10
                  </Button>
                  <Button
                    variant="outline"
                    disabled={!autoPlay}
                    onClick={stopAutoPlay}
                    className={autoPlay ? "bg-destructive text-destructive-foreground hover:bg-destructive/90" : ""}
                  >
                    Stop Auto
                  </Button>
                </div>
              </div>
            </CardContent>
            <CardFooter className="flex justify-between text-sm text-muted-foreground">
              <div>Balance: <span className="text-gold">{user.balance} coins</span></div>
              <div>{autoPlay ? `Auto Play: ${spinsRemaining} spins left` : ""}</div>
            </CardFooter>
          </Card>
        </div>

        <div>
          <Card className="casino-card">
            <CardHeader>
              <CardTitle className="flex items-center justify-between">
                <span>Payouts</span>
                {currentTier.level > 0 && (
                  <span className={`text-xs ${currentTier.badgeClass} px-2 py-0.5 rounded-full flex items-center`}>
                    <Crown className="h-3 w-3 mr-1" />
                    VIP Boosted
                  </span>
                )}
              </CardTitle>
              <CardDescription>
                Match symbols to win coins
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                <h3 className="font-semibold">Three of a Kind</h3>
                {Object.entries(payouts)
                  .filter(([key]) => key.length === 3)
                  .sort((a, b) => b[1] - a[1])
                  .map(([symbols, multiplier]) => (
                    <div key={symbols} className="flex justify-between items-center py-1">
                      <div>{symbols}</div>
                      <div className="text-gold">
                        x{getDisplayPayout(multiplier)}
                        {currentTier.level > 0 && (
                          <span className="text-xs ml-1 text-success">
                            (+{currentTier.appearingOddsBoost}%)
                          </span>
                        )}
                      </div>
                    </div>
                  ))}

                <h3 className="font-semibold mt-4">Two of a Kind</h3>
                {Object.entries(payouts)
                  .filter(([key]) => key.length === 2)
                  .sort((a, b) => b[1] - a[1])
                  .map(([symbols, multiplier]) => (
                    <div key={symbols} className="flex justify-between items-center py-1">
                      <div>{symbols}</div>
                      <div className="text-gold">
                        x{getDisplayPayout(multiplier)}
                        {currentTier.level > 0 && (
                          <span className="text-xs ml-1 text-success">
                            (+{currentTier.appearingOddsBoost}%)
                          </span>
                        )}
                      </div>
                    </div>
                  ))}
              </div>
            </CardContent>
          </Card>

          <Card className="casino-card mt-6">
            <CardHeader>
              <CardTitle>Stats</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                <div className="flex justify-between">
                  <span>Games Played:</span>
                  <span>{user.gamesPlayed}</span>
                </div>
                <div className="flex justify-between">
                  <span>Total Winnings:</span>
                  <span className="text-success">{user.winnings} coins</span>
                </div>
                <div className="flex justify-between">
                  <span>Total Losses:</span>
                  <span className="text-destructive">{user.losses} coins</span>
                </div>
                <div className="flex justify-between">
                  <span>VIP Status:</span>
                  <span className={`flex items-center ${currentTier.colorClass}`}>
                    <Crown className="h-3 w-3 mr-1" />
                    {currentTier.name}
                  </span>
                </div>
              </div>

              {currentTier.level === 0 && (
                <div className="mt-4 p-3 bg-muted/20 rounded-md text-sm">
                  <p className="text-center">
                    <a href="/vip" className="text-primary hover:underline flex items-center justify-center">
                      <Crown className="h-4 w-4 mr-1" />
                      Join VIP for better odds!
                    </a>
                  </p>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
