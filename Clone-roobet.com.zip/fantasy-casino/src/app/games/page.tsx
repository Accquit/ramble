"use client";

import Link from "next/link";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

// Game data
const games = {
  popular: [
    {
      id: "slots",
      title: "Slot Machine",
      description: "Spin to win with our virtual slot machine",
      icon: "🎰",
      path: "/games/slots",
    },
    {
      id: "dice",
      title: "Dice Roller",
      description: "Test your luck with dice games",
      icon: "🎲",
      path: "/games/dice",
    },
    {
      id: "blackjack",
      title: "Blackjack",
      description: "Play the classic card game",
      icon: "🃏",
      path: "/games/blackjack",
    },
  ],
  card: [
    {
      id: "blackjack",
      title: "Blackjack",
      description: "Play the classic card game",
      icon: "🃏",
      path: "/games/blackjack",
    },
    {
      id: "poker",
      title: "Poker",
      description: "Test your poker skills",
      icon: "♠️",
      path: "/games/poker",
      comingSoon: true,
    },
  ],
  table: [
    {
      id: "roulette",
      title: "Roulette",
      description: "Spin the wheel and place your bets",
      icon: "🔴",
      path: "/games/roulette",
      comingSoon: true,
    },
    {
      id: "dice",
      title: "Dice Roller",
      description: "Test your luck with dice games",
      icon: "🎲",
      path: "/games/dice",
    },
  ],
  slots: [
    {
      id: "slots",
      title: "Slot Machine",
      description: "Spin to win with our virtual slot machine",
      icon: "🎰",
      path: "/games/slots",
    },
    {
      id: "special-slots",
      title: "Fantasy Slots",
      description: "Special themed slot machine with bonus features",
      icon: "✨",
      path: "/games/special-slots",
      comingSoon: true,
    },
  ],
};

export default function GamesPage() {
  return (
    <div className="container py-10">
      <div className="mb-10 text-center">
        <h1 className="text-4xl font-bold tracking-tight neon-text mb-2">Casino Games</h1>
        <p className="text-xl text-muted-foreground">
          Choose from our selection of games and test your luck!
        </p>
      </div>

      <Tabs defaultValue="popular" className="w-full">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="popular">Popular</TabsTrigger>
          <TabsTrigger value="card">Card Games</TabsTrigger>
          <TabsTrigger value="table">Table Games</TabsTrigger>
          <TabsTrigger value="slots">Slot Machines</TabsTrigger>
        </TabsList>

        {Object.entries(games).map(([category, categoryGames]) => (
          <TabsContent key={category} value={category} className="mt-6">
            <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
              {categoryGames.map((game) => (
                <Card key={game.id} className={`casino-card ${game.comingSoon ? 'opacity-70' : ''}`}>
                  <CardHeader>
                    <CardTitle className="text-xl flex items-center">
                      {game.title}
                      {game.comingSoon && (
                        <span className="ml-2 inline-flex items-center rounded-full bg-primary/20 px-2 py-1 text-xs font-medium">
                          Coming Soon
                        </span>
                      )}
                    </CardTitle>
                    <CardDescription>{game.description}</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="aspect-video rounded-md bg-muted/20 flex items-center justify-center">
                      <span className="text-4xl">{game.icon}</span>
                    </div>
                  </CardContent>
                  <CardFooter>
                    <Button
                      asChild
                      className="w-full"
                      disabled={game.comingSoon}
                    >
                      {game.comingSoon ? (
                        <span>Coming Soon</span>
                      ) : (
                        <Link href={game.path}>Play Now</Link>
                      )}
                    </Button>
                  </CardFooter>
                </Card>
              ))}
            </div>
          </TabsContent>
        ))}
      </Tabs>
    </div>
  );
}
