"use client";

import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { useUser } from "@/lib/user-context";
import { useToast } from "@/components/ui/use-toast";
import { useRouter } from "next/navigation";

// Types
type CardValue = "A" | "2" | "3" | "4" | "5" | "6" | "7" | "8" | "9" | "10" | "J" | "Q" | "K";
type CardSuit = "♠" | "♥" | "♦" | "♣";
type PlayingCard = {
  value: CardValue;
  suit: CardSuit;
  faceDown?: boolean;
};

type GameState = "betting" | "playing" | "dealerTurn" | "gameOver";

// Betting options
const betOptions = [10, 25, 50, 100, 250, 500, 1000];

export default function BlackjackPage() {
  const { user, updateBalance } = useUser();
  const { toast } = useToast();
  const router = useRouter();

  // Game state
  const [gameState, setGameState] = useState<GameState>("betting");
  const [deck, setDeck] = useState<PlayingCard[]>([]);
  const [playerHand, setPlayerHand] = useState<PlayingCard[]>([]);
  const [dealerHand, setDealerHand] = useState<PlayingCard[]>([]);
  const [playerScore, setPlayerScore] = useState<number>(0);
  const [dealerScore, setDealerScore] = useState<number>(0);
  const [betAmount, setBetAmount] = useState<number>(10);
  const [result, setResult] = useState<string | null>(null);
  const [winAmount, setWinAmount] = useState<number | null>(null);

  // Check if user is logged in
  useEffect(() => {
    if (user && !user.isLoggedIn) {
      toast({
        title: "Login Required",
        description: "Please login to play games.",
        variant: "destructive",
      });
      router.push("/auth/login");
    }
  }, [user, router, toast]);

  // Initialize or reset the game
  const initGame = () => {
    const newDeck = createDeck();
    setDeck(newDeck);
    setPlayerHand([]);
    setDealerHand([]);
    setPlayerScore(0);
    setDealerScore(0);
    setResult(null);
    setWinAmount(null);
    setGameState("betting");
  };

  // Create and shuffle a new deck of cards - MODIFIED to rig the deck
  const createDeck = (): PlayingCard[] => {
    const values: CardValue[] = ["A", "2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K"];
    const suits: CardSuit[] = ["♠", "♥", "♦", "♣"];

    const newDeck: PlayingCard[] = [];

    for (const suit of suits) {
      for (const value of values) {
        newDeck.push({ value, suit });
      }
    }

    // Shuffle the deck first (for appearance)
    for (let i = newDeck.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [newDeck[i], newDeck[j]] = [newDeck[j], newDeck[i]];
    }

    // Now rig the important cards
    // Find high cards (10, J, Q, K) for the dealer's visible card
    const highCards = newDeck.filter(card =>
      card.value === "10" || card.value === "J" || card.value === "Q" || card.value === "K"
    );

    // Find cards that will cause player to bust or have weak hand
    // We want player cards to add up to 12-16 (likely to bust on hit, lose on stand)
    const weakCards = newDeck.filter(card =>
      card.value === "2" || card.value === "3" || card.value === "4" ||
      card.value === "5" || card.value === "6"
    );

    // Dealer's second card should be a strong one
    const dealerHiddenCard = newDeck.find(card => card.value === "A" || parseInt(card.value) >= 8);

    // Set up the first 4 cards to be dealt
    const riggedDeck = [...newDeck];

    if (weakCards.length >= 2 && highCards.length >= 1 && dealerHiddenCard) {
      // First 2 cards go to player
      riggedDeck[0] = weakCards[0];
      riggedDeck[1] = weakCards[1];

      // Next card is dealer's visible card (high value)
      riggedDeck[2] = highCards[0];

      // Dealer's hidden card is a strong one
      riggedDeck[3] = dealerHiddenCard;

      // For any player hits, put high cards at the top of the deck to cause busts
      const bustCards = newDeck.filter(card =>
        card.value === "10" || card.value === "J" || card.value === "Q" || card.value === "K"
      );

      if (bustCards.length >= 3) {
        riggedDeck[4] = bustCards[1];
        riggedDeck[5] = bustCards[2];
      }
    }

    return riggedDeck;
  };

  // Draw a card from the deck
  const drawCard = (faceDown: boolean = false): PlayingCard => {
    const card = deck[0];
    setDeck(deck.slice(1));
    return { ...card, faceDown };
  };

  // Calculate the score of a hand
  const calculateScore = (hand: PlayingCard[]): number => {
    const visibleCards = hand.filter(card => !card.faceDown);

    let score = 0;
    let aces = 0;

    for (const card of visibleCards) {
      if (card.value === "A") {
        aces++;
        score += 11;
      } else if (["K", "Q", "J"].includes(card.value)) {
        score += 10;
      } else {
        score += parseInt(card.value);
      }
    }

    // Adjust aces if needed
    while (score > 21 && aces > 0) {
      score -= 10;
      aces--;
    }

    return score;
  };

  // Start a new game
  const startGame = () => {
    if (!user) return;

    if (user.balance < betAmount) {
      toast({
        title: "Insufficient funds",
        description: "You don't have enough coins to place this bet.",
        variant: "destructive",
      });
      return;
    }

    // Deduct bet amount
    updateBalance(-betAmount);

    const newDeck = createDeck();
    setDeck(newDeck);

    // Initial deal
    const pCard1 = newDeck[0];
    const dCard1 = newDeck[1];
    const pCard2 = newDeck[2];
    const dCard2 = { ...newDeck[3], faceDown: true };

    const playerStartingHand = [pCard1, pCard2];
    const dealerStartingHand = [dCard1, dCard2];

    setPlayerHand(playerStartingHand);
    setDealerHand(dealerStartingHand);

    setPlayerScore(calculateScore(playerStartingHand));
    setDealerScore(calculateScore(dealerStartingHand));

    setGameState("playing");

    // Remaining deck
    setDeck(newDeck.slice(4));

    // Check for natural blackjack
    if (calculateScore(playerStartingHand) === 21) {
      if (calculateScore([dCard1, { ...dCard2, faceDown: false }]) === 21) {
        // Both have blackjack - push
        setResult("Push - both have Blackjack!");
        setWinAmount(betAmount);
        updateBalance(betAmount);
        setGameState("gameOver");
      } else {
        // Player has blackjack - win 3:2
        const blackjackWin = Math.floor(betAmount * 2.5);
        setResult("Blackjack! You win!");
        setWinAmount(blackjackWin);
        updateBalance(blackjackWin);
        setGameState("gameOver");
      }
    }
  };

  // Player hits - draw another card
  const playerHit = () => {
    const newCard = drawCard();
    const newHand = [...playerHand, newCard];
    setPlayerHand(newHand);

    const newScore = calculateScore(newHand);
    setPlayerScore(newScore);

    // Check if player busts
    if (newScore > 21) {
      setResult("Bust! You lose.");
      setGameState("gameOver");
    }
  };

  // Player stands - dealer's turn
  const playerStand = () => {
    // Reveal dealer's hidden card
    const revealedDealerHand = dealerHand.map(card => ({ ...card, faceDown: false }));
    setDealerHand(revealedDealerHand);

    const dealerCurrentScore = calculateScore(revealedDealerHand);
    setDealerScore(dealerCurrentScore);

    // Start dealer's turn
    setGameState("dealerTurn");
  };

  // Dealer's turn logic
  useEffect(() => {
    if (gameState === "dealerTurn") {
      const dealerPlay = async () => {
        let currentDealerHand = dealerHand.map(card => ({ ...card, faceDown: false }));
        let currentDealerScore = calculateScore(currentDealerHand);
        setDealerScore(currentDealerScore);

        // Dealer draws until reaching 17 or higher
        while (currentDealerScore < 17) {
          // Pause for animation effect
          await new Promise(resolve => setTimeout(resolve, 1000));

          const newCard = drawCard();
          currentDealerHand = [...currentDealerHand, newCard];
          setDealerHand(currentDealerHand);

          currentDealerScore = calculateScore(currentDealerHand);
          setDealerScore(currentDealerScore);
        }

        // Determine winner
        determineWinner(playerScore, currentDealerScore);
      };

      dealerPlay();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [gameState]);

  // Determine the winner and update balance
  const determineWinner = (pScore: number, dScore: number) => {
    if (dScore > 21) {
      // Dealer busts
      setResult("Dealer busts! You win!");
      const win = betAmount * 2;
      setWinAmount(win);
      updateBalance(win);
    } else if (pScore > dScore) {
      // Player wins
      setResult("You win!");
      const win = betAmount * 2;
      setWinAmount(win);
      updateBalance(win);
    } else if (pScore < dScore) {
      // Dealer wins
      setResult("Dealer wins!");
    } else {
      // Push - tie
      setResult("Push - it's a tie!");
      setWinAmount(betAmount);
      updateBalance(betAmount);
    }

    setGameState("gameOver");
  };

  // Get card color based on suit
  const getCardColor = (suit: CardSuit) => {
    return suit === "♥" || suit === "♦" ? "text-red-500" : "text-white";
  };

  // Render a card
  const renderCard = (card: PlayingCard, index: number) => {
    if (card.faceDown) {
      return (
        <div key={index} className="h-28 w-20 rounded-md bg-primary flex items-center justify-center">
          <div className="h-24 w-16 rounded border-2 border-muted-foreground bg-card flex items-center justify-center">
            <span className="text-2xl">?</span>
          </div>
        </div>
      );
    }

    return (
      <div key={index} className="h-28 w-20 rounded-md bg-white flex items-center justify-center">
        <div className={`h-24 w-16 rounded border border-muted-foreground bg-card flex flex-col items-center justify-between p-1 ${getCardColor(card.suit)}`}>
          <div className="text-sm font-bold">{card.value}</div>
          <div className="text-xl">{card.suit}</div>
          <div className="text-sm font-bold rotate-180">{card.value}</div>
        </div>
      </div>
    );
  };

  if (!user || !user.isLoggedIn) {
    return <div className="container py-20 text-center">Loading...</div>;
  }

  return (
    <div className="container py-10">
      <div className="mb-10 text-center">
        <h1 className="text-4xl font-bold tracking-tight neon-text mb-2">Blackjack</h1>
        <p className="text-xl text-muted-foreground">
          Try to beat the dealer without going over 21
        </p>
      </div>

      <div className="grid gap-6 md:grid-cols-3">
        <div className="md:col-span-2">
          <Card className="casino-card">
            <CardHeader>
              <div className="flex justify-between items-center">
                <div>
                  <CardTitle>Blackjack</CardTitle>
                  <CardDescription>
                    {gameState === "betting"
                      ? "Place your bet to start"
                      : gameState === "playing"
                      ? "Your turn - Hit or Stand"
                      : gameState === "dealerTurn"
                      ? "Dealer's turn"
                      : "Game over"}
                  </CardDescription>
                </div>
                {(gameState === "playing" || gameState === "dealerTurn" || gameState === "gameOver") && (
                  <div className="text-sm">
                    <div>Bet: <span className="text-gold">{betAmount} coins</span></div>
                  </div>
                )}
              </div>
            </CardHeader>

            <CardContent>
              {/* Game Table */}
              <div className="bg-green-900/50 rounded-xl p-6 min-h-[400px]">
                {gameState === "betting" ? (
                  <div className="flex flex-col items-center justify-center h-full">
                    <div className="text-xl mb-6">Place your bet</div>
                    <div className="flex flex-wrap gap-2 justify-center mb-6">
                      {betOptions.map((bet) => (
                        <Button
                          key={bet}
                          variant={betAmount === bet ? "default" : "outline"}
                          onClick={() => setBetAmount(bet)}
                          disabled={user.balance < bet}
                        >
                          {bet}
                        </Button>
                      ))}
                    </div>
                    <Button
                      onClick={startGame}
                      className="w-48"
                      disabled={user.balance < betAmount}
                    >
                      Deal Cards
                    </Button>
                  </div>
                ) : (
                  <div className="space-y-8">
                    {/* Dealer's Hand */}
                    <div>
                      <div className="flex justify-between mb-2">
                        <div className="text-lg">Dealer's Hand</div>
                        <div>Score: {dealerScore}</div>
                      </div>
                      <div className="flex gap-2 overflow-auto pb-2">
                        {dealerHand.map((card, index) => renderCard(card, index))}
                      </div>
                    </div>

                    {/* Player's Hand */}
                    <div>
                      <div className="flex justify-between mb-2">
                        <div className="text-lg">Your Hand</div>
                        <div>Score: {playerScore}</div>
                      </div>
                      <div className="flex gap-2 overflow-auto pb-2">
                        {playerHand.map((card, index) => renderCard(card, index))}
                      </div>
                    </div>

                    {/* Game Result */}
                    {result && (
                      <div className={`text-center text-xl font-bold p-2 rounded ${result.includes("win") ? "text-success" : result.includes("Bust") ? "text-destructive" : "text-primary"}`}>
                        {result}
                        {winAmount && <div className="text-gold mt-1">+{winAmount} coins</div>}
                      </div>
                    )}

                    {/* Game Controls */}
                    <div className="flex justify-center gap-4">
                      {gameState === "playing" && (
                        <>
                          <Button onClick={playerHit} size="lg">
                            Hit
                          </Button>
                          <Button onClick={playerStand} size="lg" variant="outline">
                            Stand
                          </Button>
                        </>
                      )}

                      {gameState === "gameOver" && (
                        <Button onClick={initGame} size="lg">
                          Play Again
                        </Button>
                      )}
                    </div>
                  </div>
                )}
              </div>
            </CardContent>

            <CardFooter className="flex justify-between text-sm text-muted-foreground">
              <div>Balance: <span className="text-gold">{user.balance} coins</span></div>
            </CardFooter>
          </Card>
        </div>

        <div>
          <Card className="casino-card">
            <CardHeader>
              <CardTitle>Game Rules</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3 text-sm">
              <div>
                <h3 className="font-semibold">Objective</h3>
                <p className="text-muted-foreground">
                  Beat the dealer's hand without going over 21.
                </p>
              </div>

              <div>
                <h3 className="font-semibold">Card Values</h3>
                <p className="text-muted-foreground">
                  • Number cards: Face value<br />
                  • Face cards (J, Q, K): 10 points<br />
                  • Ace: 1 or 11 points (whichever is better)
                </p>
              </div>

              <div>
                <h3 className="font-semibold">Actions</h3>
                <p className="text-muted-foreground">
                  • Hit: Draw another card<br />
                  • Stand: End your turn<br />
                </p>
              </div>

              <div>
                <h3 className="font-semibold">Payouts</h3>
                <p className="text-muted-foreground">
                  • Win: 1:1 (double your bet)<br />
                  • Blackjack (A + 10/J/Q/K): 3:2<br />
                  • Push (tie): Bet returned
                </p>
              </div>
            </CardContent>
          </Card>

          <Card className="casino-card mt-6">
            <CardHeader>
              <CardTitle>Stats</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                <div className="flex justify-between">
                  <span>Games Played:</span>
                  <span>{user.gamesPlayed}</span>
                </div>
                <div className="flex justify-between">
                  <span>Total Winnings:</span>
                  <span className="text-success">{user.winnings} coins</span>
                </div>
                <div className="flex justify-between">
                  <span>Total Losses:</span>
                  <span className="text-destructive">{user.losses} coins</span>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
