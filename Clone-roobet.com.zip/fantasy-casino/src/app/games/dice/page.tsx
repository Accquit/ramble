"use client";

import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useUser } from "@/lib/user-context";
import { useVip } from "@/lib/vip-context";
import { useToast } from "@/components/ui/use-toast";
import { useRouter } from "next/navigation";
import { Slider } from "@/components/ui/slider";
import { Crown, Info } from "lucide-react";

// Betting options
const betOptions = [10, 25, 50, 100, 250, 500, 1000];

export default function DicePage() {
  const { user, updateBalance } = useUser();
  const { currentTier } = useVip();
  const { toast } = useToast();
  const router = useRouter();

  const [diceValue, setDiceValue] = useState<number>(1);
  const [previousDiceValue, setPreviousDiceValue] = useState<number | null>(null);
  const [rolling, setRolling] = useState<boolean>(false);
  const [betAmount, setBetAmount] = useState<number>(10);
  const [winAmount, setWinAmount] = useState<number | null>(null);
  const [gameMode, setGameMode] = useState<"highlow" | "target">("highlow");
  const [showVipInfo, setShowVipInfo] = useState<boolean>(false);

  // Target mode settings
  const [targetNumber, setTargetNumber] = useState<number>(3);
  const [betType, setBetType] = useState<"over" | "under">("over");

  // High/Low settings
  const [prediction, setPrediction] = useState<"higher" | "lower" | null>(null);

  // Check if user is logged in
  useEffect(() => {
    if (user && !user.isLoggedIn) {
      toast({
        title: "Login Required",
        description: "Please login to play games.",
        variant: "destructive",
      });
      router.push("/auth/login");
    }
  }, [user, router, toast]);

  // Reset winAmount when changing bet
  useEffect(() => {
    setWinAmount(null);
  }, [betAmount, gameMode, targetNumber, betType]);

  // Roll the dice - MODIFIED to ensure player always loses
  const rollDice = () => {
    if (!user) return;

    if (user.balance < betAmount) {
      toast({
        title: "Insufficient funds",
        description: "You don't have enough coins to place this bet.",
        variant: "destructive",
      });
      return;
    }

    // In high/low mode, need to have a prediction
    if (gameMode === "highlow" && prediction === null) {
      toast({
        title: "Choose a prediction",
        description: "Predict if the next roll will be higher or lower.",
        variant: "destructive",
      });
      return;
    }

    // Deduct bet amount
    updateBalance(-betAmount);

    setRolling(true);
    setPreviousDiceValue(diceValue);
    setWinAmount(null);

    // Animate rolling with random values
    let rollCount = 0;
    const maxRolls = 10;
    const rollInterval = setInterval(() => {
      const randomValue = Math.floor(Math.random() * 6) + 1;
      setDiceValue(randomValue);

      rollCount++;

      if (rollCount >= maxRolls) {
        clearInterval(rollInterval);

        // MODIFIED: Rig the final dice value to ensure player loses
        let newValue = 1;

        if (gameMode === "highlow" && prediction !== null) {
          // Make sure the roll is opposite of what the player predicted
          if (prediction === "higher") {
            // Player predicted higher, so roll lower
            newValue = previousDiceValue === 1 ? 1 : Math.max(1, previousDiceValue! - 1);
          } else {
            // Player predicted lower, so roll higher
            newValue = previousDiceValue === 6 ? 6 : Math.min(6, previousDiceValue! + 1);
          }
        } else if (gameMode === "target") {
          // Make sure the roll doesn't match the player's bet
          if (betType === "over") {
            // Player bet over target, so roll below or equal to target
            newValue = Math.min(targetNumber, 6);
          } else {
            // Player bet under target, so roll above or equal to target
            newValue = Math.max(targetNumber, 1);
          }
        }

        setDiceValue(newValue);
        setRolling(false);

        checkWin(newValue);
      }
    }, 100);
  };

  // Check if the player has won
  const checkWin = (newValue: number) => {
    let win = 0;

    if (gameMode === "highlow") {
      // Need a previous value to compare to
      if (previousDiceValue !== null && prediction !== null) {
        if (
          (prediction === "higher" && newValue > previousDiceValue) ||
          (prediction === "lower" && newValue < previousDiceValue)
        ) {
          // Win is 1.8x the bet (accounting for house edge)
          win = Math.floor(betAmount * 1.8);
        } else if (newValue === previousDiceValue) {
          // Push (tie) - return the original bet
          win = betAmount;
          toast({
            title: "Push",
            description: "It's a tie! Your bet has been returned.",
          });
        }
      }
    } else if (gameMode === "target") {
      if (
        (betType === "over" && newValue > targetNumber) ||
        (betType === "under" && newValue < targetNumber)
      ) {
        // Calculate win multiplier based on probability
        // The further the target is from the average (3.5), the higher the payout
        const multiplier = calculateMultiplier(targetNumber, betType);
        win = Math.floor(betAmount * multiplier);
      }
    }

    if (win > 0) {
      setWinAmount(win);
      updateBalance(win);

      if (win > betAmount) {
        toast({
          title: "Winner!",
          description: `You won ${win} coins!`,
        });
      }
    }
  };

  // Calculate multiplier for target mode
  const calculateMultiplier = (target: number, type: "over" | "under"): number => {
    if (type === "over") {
      // Odds for rolling over X (out of 6)
      const odds = [5/6, 4/6, 3/6, 2/6, 1/6, 0];
      const multiplier = odds[target - 1] > 0 ? 0.9 / odds[target - 1] : 0;
      return Number(multiplier.toFixed(2));
    } else {
      // Odds for rolling under X (out of 6)
      const odds = [0, 1/6, 2/6, 3/6, 4/6, 5/6];
      const multiplier = odds[target - 1] > 0 ? 0.9 / odds[target - 1] : 0;
      return Number(multiplier.toFixed(2));
    }
  };

  // Get the dice face
  const getDiceFace = (value: number) => {
    switch (value) {
      case 1: return "⚀";
      case 2: return "⚁";
      case 3: return "⚂";
      case 4: return "⚃";
      case 5: return "⚄";
      case 6: return "⚅";
      default: return "⚀";
    }
  };

  // Calculate available multiplier for UI
  const getMultiplier = (): number => {
    if (gameMode === "highlow") {
      return getDisplayMultiplier(1.8);
    } else {
      return getDisplayMultiplier(calculateMultiplier(targetNumber, betType));
    }
  };

  // Get VIP-boosted multiplier (for display only)
  const getDisplayMultiplier = (baseMultiplier: number): number => {
    if (currentTier.appearingOddsBoost === 0) return baseMultiplier;

    // Calculate boosted multiplier for display only
    const boost = 1 + (currentTier.appearingOddsBoost / 100);
    return parseFloat((baseMultiplier * boost).toFixed(2));
  };

  // Check if the bet is valid
  const canBet = (): boolean => {
    if (!user || user.balance < betAmount || rolling) return false;

    if (gameMode === "highlow") {
      return prediction !== null;
    }

    return true;
  };

  if (!user || !user.isLoggedIn) {
    return <div className="container py-20 text-center">Loading...</div>;
  }

  return (
    <div className="container py-10">
      <div className="mb-10 text-center">
        <h1 className="text-4xl font-bold tracking-tight neon-text mb-2">Dice Game</h1>
        <p className="text-xl text-muted-foreground">
          Test your luck with our dice games!
        </p>
      </div>

      <div className="grid gap-6 md:grid-cols-3">
        <div className="md:col-span-2">
          <Card className="casino-card">
            <CardHeader>
              <div className="flex justify-between items-center">
                <Tabs defaultValue="highlow" onValueChange={(value) => setGameMode(value as "highlow" | "target")}>
                  <TabsList className="grid w-full grid-cols-2">
                    <TabsTrigger value="highlow">Higher or Lower</TabsTrigger>
                    <TabsTrigger value="target">Target Number</TabsTrigger>
                  </TabsList>

                  <TabsContent value="highlow" className="mt-4">
                    <CardTitle className="text-center">Higher or Lower</CardTitle>
                    <CardDescription className="text-center">
                      Predict if the next roll will be higher or lower than the current roll
                    </CardDescription>
                  </TabsContent>

                  <TabsContent value="target" className="mt-4">
                    <CardTitle className="text-center">Target Number</CardTitle>
                    <CardDescription className="text-center">
                      Bet if the dice will roll over or under your target number
                    </CardDescription>
                  </TabsContent>
                </Tabs>

                {currentTier.level > 0 && (
                  <div
                    className={`flex items-center gap-1 ${currentTier.badgeClass} px-2 py-1 rounded-full text-xs cursor-pointer`}
                    onClick={() => setShowVipInfo(!showVipInfo)}
                  >
                    <Crown className="h-3 w-3" />
                    <span>+{currentTier.appearingOddsBoost}% Odds</span>
                    <Info className="h-3 w-3 ml-0.5" />
                  </div>
                )}
              </div>

              {showVipInfo && (
                <div className="mt-2 p-2 bg-muted/20 rounded-md text-xs">
                  <p className="text-muted-foreground">
                    Your {currentTier.name} VIP status gives you a +{currentTier.appearingOddsBoost}% boost to your winning odds!
                    This applies to all games and increases your payout multipliers.
                  </p>
                </div>
              )}
            </CardHeader>

            <CardContent className="flex flex-col items-center">
              {/* Dice Display */}
              <div className="flex justify-center gap-8 my-6">
                {previousDiceValue !== null && gameMode === "highlow" && (
                  <div className="flex flex-col items-center">
                    <div className="text-sm text-muted-foreground mb-2">Previous Roll</div>
                    <div className="flex h-24 w-24 items-center justify-center rounded-md border border-border bg-muted text-5xl">
                      {getDiceFace(previousDiceValue)}
                    </div>
                  </div>
                )}

                <div className="flex flex-col items-center">
                  <div className="text-sm text-muted-foreground mb-2">Current Roll</div>
                  <div className={`flex h-24 w-24 items-center justify-center rounded-md border border-border bg-card text-5xl
                  ${rolling ? "animate-bounce" : ""}`}>
                    {getDiceFace(diceValue)}
                  </div>
                </div>
              </div>

              {/* Game Mode Specific Controls */}
              {gameMode === "highlow" && (
                <div className="w-full max-w-md my-4">
                  <div className="text-sm text-muted-foreground mb-2">Your Prediction:</div>
                  <div className="flex gap-4 justify-center">
                    <Button
                      variant={prediction === "higher" ? "default" : "outline"}
                      className={prediction === "higher" ? "w-1/2 border-primary" : "w-1/2"}
                      onClick={() => setPrediction("higher")}
                      disabled={rolling}
                    >
                      Higher
                    </Button>
                    <Button
                      variant={prediction === "lower" ? "default" : "outline"}
                      className={prediction === "lower" ? "w-1/2 border-primary" : "w-1/2"}
                      onClick={() => setPrediction("lower")}
                      disabled={rolling}
                    >
                      Lower
                    </Button>
                  </div>

                  {prediction && (
                    <div className="text-center mt-2 text-sm">
                      Predicting the next roll will be <span className="font-semibold">{prediction}</span> than {previousDiceValue || diceValue}
                    </div>
                  )}
                </div>
              )}

              {gameMode === "target" && (
                <div className="w-full max-w-md my-4">
                  <div className="text-sm text-muted-foreground mb-2">Set Target Number: {targetNumber}</div>
                  <Slider
                    value={[targetNumber]}
                    min={1}
                    max={6}
                    step={1}
                    onValueChange={(value) => setTargetNumber(value[0])}
                    disabled={rolling}
                    className="my-4"
                  />

                  <div className="flex gap-4 justify-center">
                    <Button
                      variant={betType === "over" ? "default" : "outline"}
                      className={betType === "over" ? "w-1/2 border-primary" : "w-1/2"}
                      onClick={() => setBetType("over")}
                      disabled={rolling}
                    >
                      Over {targetNumber}
                    </Button>
                    <Button
                      variant={betType === "under" ? "default" : "outline"}
                      className={betType === "under" ? "w-1/2 border-primary" : "w-1/2"}
                      onClick={() => setBetType("under")}
                      disabled={rolling}
                    >
                      Under {targetNumber}
                    </Button>
                  </div>

                  <div className="text-center mt-2 text-sm">
                    Win <span className="font-semibold text-gold">{getMultiplier()}x
                    {currentTier.level > 0 && (
                      <span className="text-xs text-success ml-1">(+{currentTier.appearingOddsBoost}%)</span>
                    )}
                    </span> your bet if the dice rolls
                    <span className="font-semibold"> {betType === "over" ? "higher than" : "lower than"} {targetNumber}</span>
                  </div>
                </div>
              )}

              {/* Win Display */}
              {winAmount !== null && (
                <div className="my-4 text-center">
                  <div className="text-2xl font-bold text-gold">
                    You won {winAmount} coins!
                  </div>
                </div>
              )}

              {/* Betting Controls */}
              <div className="w-full max-w-md mt-4">
                <div className="mb-4">
                  <div className="text-sm text-muted-foreground mb-2">Select Bet Amount:</div>
                  <div className="flex flex-wrap gap-2 justify-center">
                    {betOptions.map((bet) => (
                      <Button
                        key={bet}
                        variant={betAmount === bet ? "default" : "outline"}
                        size="sm"
                        onClick={() => setBetAmount(bet)}
                        disabled={rolling || user.balance < bet}
                      >
                        {bet}
                      </Button>
                    ))}
                  </div>
                </div>

                {/* Roll Button */}
                <Button
                  className="w-full h-14 text-lg neon-border"
                  disabled={!canBet()}
                  onClick={rollDice}
                >
                  {rolling ? "Rolling..." : `Roll Dice (${betAmount} coins)`}
                </Button>
              </div>
            </CardContent>

            <CardFooter className="text-sm text-muted-foreground">
              <div>Balance: <span className="text-gold">{user.balance} coins</span></div>
            </CardFooter>
          </Card>
        </div>

        <div>
          <Card className="casino-card">
            <CardHeader>
              <CardTitle className="flex items-center justify-between">
                <span>Game Rules</span>
                {currentTier.level > 0 && (
                  <span className={`text-xs ${currentTier.badgeClass} px-2 py-0.5 rounded-full flex items-center`}>
                    <Crown className="h-3 w-3 mr-1" />
                    VIP Boosted
                  </span>
                )}
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <h3 className="font-semibold">Higher or Lower</h3>
                <p className="text-sm text-muted-foreground">
                  Predict if the next dice roll will be higher or lower than the current roll.
                  Win {getDisplayMultiplier(1.8)}x
                  {currentTier.level > 0 && (
                    <span className="text-xs text-success ml-1">(+{currentTier.appearingOddsBoost}%)</span>
                  )} your bet if you're correct.
                  If the rolls are equal, your bet is returned.
                </p>
              </div>

              <div>
                <h3 className="font-semibold">Target Number</h3>
                <p className="text-sm text-muted-foreground">
                  Set a target number and bet whether the dice will roll over or under it.
                  The payout depends on the probability - the harder the bet, the higher the payout.
                </p>
              </div>
            </CardContent>
          </Card>

          <Card className="casino-card mt-6">
            <CardHeader>
              <CardTitle>Target Payouts</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <h3 className="font-semibold text-sm">Over Target</h3>
                    <div className="text-xs text-muted-foreground">
                      <div className="flex justify-between my-1">
                        <span>Over 1:</span>
                        <span className="text-gold">
                          {getDisplayMultiplier(1.1)}x
                          {currentTier.level > 0 && (
                            <span className="text-xs text-success ml-1">(+{currentTier.appearingOddsBoost}%)</span>
                          )}
                        </span>
                      </div>
                      <div className="flex justify-between my-1">
                        <span>Over 2:</span>
                        <span className="text-gold">
                          {getDisplayMultiplier(1.4)}x
                          {currentTier.level > 0 && (
                            <span className="text-xs text-success ml-1">(+{currentTier.appearingOddsBoost}%)</span>
                          )}
                        </span>
                      </div>
                      <div className="flex justify-between my-1">
                        <span>Over 3:</span>
                        <span className="text-gold">
                          {getDisplayMultiplier(1.8)}x
                          {currentTier.level > 0 && (
                            <span className="text-xs text-success ml-1">(+{currentTier.appearingOddsBoost}%)</span>
                          )}
                        </span>
                      </div>
                      <div className="flex justify-between my-1">
                        <span>Over 4:</span>
                        <span className="text-gold">
                          {getDisplayMultiplier(2.7)}x
                          {currentTier.level > 0 && (
                            <span className="text-xs text-success ml-1">(+{currentTier.appearingOddsBoost}%)</span>
                          )}
                        </span>
                      </div>
                      <div className="flex justify-between my-1">
                        <span>Over 5:</span>
                        <span className="text-gold">
                          {getDisplayMultiplier(5.4)}x
                          {currentTier.level > 0 && (
                            <span className="text-xs text-success ml-1">(+{currentTier.appearingOddsBoost}%)</span>
                          )}
                        </span>
                      </div>
                    </div>
                  </div>

                  <div>
                    <h3 className="font-semibold text-sm">Under Target</h3>
                    <div className="text-xs text-muted-foreground">
                      <div className="flex justify-between my-1">
                        <span>Under 2:</span>
                        <span className="text-gold">
                          {getDisplayMultiplier(5.4)}x
                          {currentTier.level > 0 && (
                            <span className="text-xs text-success ml-1">(+{currentTier.appearingOddsBoost}%)</span>
                          )}
                        </span>
                      </div>
                      <div className="flex justify-between my-1">
                        <span>Under 3:</span>
                        <span className="text-gold">
                          {getDisplayMultiplier(2.7)}x
                          {currentTier.level > 0 && (
                            <span className="text-xs text-success ml-1">(+{currentTier.appearingOddsBoost}%)</span>
                          )}
                        </span>
                      </div>
                      <div className="flex justify-between my-1">
                        <span>Under 4:</span>
                        <span className="text-gold">
                          {getDisplayMultiplier(1.8)}x
                          {currentTier.level > 0 && (
                            <span className="text-xs text-success ml-1">(+{currentTier.appearingOddsBoost}%)</span>
                          )}
                        </span>
                      </div>
                      <div className="flex justify-between my-1">
                        <span>Under 5:</span>
                        <span className="text-gold">
                          {getDisplayMultiplier(1.4)}x
                          {currentTier.level > 0 && (
                            <span className="text-xs text-success ml-1">(+{currentTier.appearingOddsBoost}%)</span>
                          )}
                        </span>
                      </div>
                      <div className="flex justify-between my-1">
                        <span>Under 6:</span>
                        <span className="text-gold">
                          {getDisplayMultiplier(1.1)}x
                          {currentTier.level > 0 && (
                            <span className="text-xs text-success ml-1">(+{currentTier.appearingOddsBoost}%)</span>
                          )}
                        </span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="casino-card mt-6">
            <CardHeader>
              <CardTitle>Stats</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                <div className="flex justify-between">
                  <span>Games Played:</span>
                  <span>{user.gamesPlayed}</span>
                </div>
                <div className="flex justify-between">
                  <span>Total Winnings:</span>
                  <span className="text-success">{user.winnings} coins</span>
                </div>
                <div className="flex justify-between">
                  <span>Total Losses:</span>
                  <span className="text-destructive">{user.losses} coins</span>
                </div>
                <div className="flex justify-between">
                  <span>VIP Status:</span>
                  <span className={`flex items-center ${currentTier.colorClass}`}>
                    <Crown className="h-3 w-3 mr-1" />
                    {currentTier.name}
                  </span>
                </div>
              </div>

              {currentTier.level === 0 && (
                <div className="mt-4 p-3 bg-muted/20 rounded-md text-sm">
                  <p className="text-center">
                    <a href="/vip" className="text-primary hover:underline flex items-center justify-center">
                      <Crown className="h-4 w-4 mr-1" />
                      Join VIP for better odds!
                    </a>
                  </p>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
