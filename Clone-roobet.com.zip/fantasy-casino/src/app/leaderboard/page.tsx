"use client";

import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

// Mock data for leaderboards
const leaderboardData = {
  balance: [
    { id: 1, username: "RoyalFlush", balance: 250000, avatar: "" },
    { id: 2, username: "LuckyDiamond", balance: 175000, avatar: "" },
    { id: 3, username: "HighRoller", balance: 145000, avatar: "" },
    { id: 4, username: "AceKing", balance: 120000, avatar: "" },
    { id: 5, username: "GoldMiner", balance: 115000, avatar: "" },
    { id: 6, username: "SlotMaster", balance: 95000, avatar: "" },
    { id: 7, username: "BlackjackPro", balance: 85000, avatar: "" },
    { id: 8, username: "DiceQueen", balance: 75000, avatar: "" },
    { id: 9, username: "RouletteWizard", balance: 65000, avatar: "" },
    { id: 10, username: "JackpotWinner", balance: 60000, avatar: "" },
  ],
  winnings: [
    { id: 1, username: "GoldenTouch", winnings: 500000, avatar: "" },
    { id: 2, username: "MegaWinner", winnings: 350000, avatar: "" },
    { id: 3, username: "RoyalFlush", winnings: 325000, avatar: "" },
    { id: 4, username: "LuckyCharm", winnings: 275000, avatar: "" },
    { id: 5, username: "FortuneKing", winnings: 250000, avatar: "" },
    { id: 6, username: "DiamondHand", winnings: 200000, avatar: "" },
    { id: 7, username: "HighRoller", winnings: 175000, avatar: "" },
    { id: 8, username: "AcePlayer", winnings: 150000, avatar: "" },
    { id: 9, username: "CardShark", winnings: 140000, avatar: "" },
    { id: 10, username: "LuckyDiamond", winnings: 125000, avatar: "" },
  ],
  games: [
    { id: 1, username: "GrindMaster", gamesPlayed: 350, avatar: "" },
    { id: 2, username: "DailyPlayer", gamesPlayed: 320, avatar: "" },
    { id: 3, username: "GameAddict", gamesPlayed: 280, avatar: "" },
    { id: 4, username: "NonStop", gamesPlayed: 240, avatar: "" },
    { id: 5, username: "CasinoLover", gamesPlayed: 210, avatar: "" },
    { id: 6, username: "SlotSpinner", gamesPlayed: 190, avatar: "" },
    { id: 7, username: "CardCounter", gamesPlayed: 180, avatar: "" },
    { id: 8, username: "DiceRoller", gamesPlayed: 165, avatar: "" },
    { id: 9, username: "TableKing", gamesPlayed: 155, avatar: "" },
    { id: 10, username: "JackpotHunter", gamesPlayed: 140, avatar: "" },
  ],
};

export default function LeaderboardPage() {
  return (
    <div className="container py-10">
      <div className="mb-10 text-center">
        <h1 className="text-4xl font-bold tracking-tight neon-text mb-2">Leaderboard</h1>
        <p className="text-xl text-muted-foreground">
          Top players in Fantasy Casino
        </p>
      </div>

      <Card className="casino-card">
        <CardHeader>
          <CardTitle>Casino Champions</CardTitle>
          <CardDescription>
            See who's leading in different categories
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Tabs defaultValue="balance">
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="balance">Current Balance</TabsTrigger>
              <TabsTrigger value="winnings">Total Winnings</TabsTrigger>
              <TabsTrigger value="games">Games Played</TabsTrigger>
            </TabsList>

            <TabsContent value="balance" className="mt-6">
              <div className="rounded-md border overflow-hidden">
                <table className="w-full">
                  <thead className="bg-muted/50">
                    <tr>
                      <th className="py-3 px-4 text-left">Rank</th>
                      <th className="py-3 px-4 text-left">Player</th>
                      <th className="py-3 px-4 text-right">Current Balance</th>
                    </tr>
                  </thead>
                  <tbody>
                    {leaderboardData.balance.map((player, index) => (
                      <tr key={player.id} className="border-t">
                        <td className="py-3 px-4">
                          <div className="flex items-center">
                            {index === 0 ? (
                              <span className="text-xl">🥇</span>
                            ) : index === 1 ? (
                              <span className="text-xl">🥈</span>
                            ) : index === 2 ? (
                              <span className="text-xl">🥉</span>
                            ) : (
                              <span className="mx-2 text-muted-foreground">{index + 1}</span>
                            )}
                          </div>
                        </td>
                        <td className="py-3 px-4">
                          <div className="flex items-center">
                            <Avatar className="h-8 w-8 mr-2">
                              <AvatarImage src={player.avatar} alt={player.username} />
                              <AvatarFallback>{player.username[0]}</AvatarFallback>
                            </Avatar>
                            <span className="font-medium">{player.username}</span>
                          </div>
                        </td>
                        <td className="py-3 px-4 text-right font-medium text-gold">
                          {player.balance.toLocaleString()} coins
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </TabsContent>

            <TabsContent value="winnings" className="mt-6">
              <div className="rounded-md border overflow-hidden">
                <table className="w-full">
                  <thead className="bg-muted/50">
                    <tr>
                      <th className="py-3 px-4 text-left">Rank</th>
                      <th className="py-3 px-4 text-left">Player</th>
                      <th className="py-3 px-4 text-right">Total Winnings</th>
                    </tr>
                  </thead>
                  <tbody>
                    {leaderboardData.winnings.map((player, index) => (
                      <tr key={player.id} className="border-t">
                        <td className="py-3 px-4">
                          <div className="flex items-center">
                            {index === 0 ? (
                              <span className="text-xl">🥇</span>
                            ) : index === 1 ? (
                              <span className="text-xl">🥈</span>
                            ) : index === 2 ? (
                              <span className="text-xl">🥉</span>
                            ) : (
                              <span className="mx-2 text-muted-foreground">{index + 1}</span>
                            )}
                          </div>
                        </td>
                        <td className="py-3 px-4">
                          <div className="flex items-center">
                            <Avatar className="h-8 w-8 mr-2">
                              <AvatarImage src={player.avatar} alt={player.username} />
                              <AvatarFallback>{player.username[0]}</AvatarFallback>
                            </Avatar>
                            <span className="font-medium">{player.username}</span>
                          </div>
                        </td>
                        <td className="py-3 px-4 text-right font-medium text-success">
                          {player.winnings.toLocaleString()} coins
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </TabsContent>

            <TabsContent value="games" className="mt-6">
              <div className="rounded-md border overflow-hidden">
                <table className="w-full">
                  <thead className="bg-muted/50">
                    <tr>
                      <th className="py-3 px-4 text-left">Rank</th>
                      <th className="py-3 px-4 text-left">Player</th>
                      <th className="py-3 px-4 text-right">Games Played</th>
                    </tr>
                  </thead>
                  <tbody>
                    {leaderboardData.games.map((player, index) => (
                      <tr key={player.id} className="border-t">
                        <td className="py-3 px-4">
                          <div className="flex items-center">
                            {index === 0 ? (
                              <span className="text-xl">🥇</span>
                            ) : index === 1 ? (
                              <span className="text-xl">🥈</span>
                            ) : index === 2 ? (
                              <span className="text-xl">🥉</span>
                            ) : (
                              <span className="mx-2 text-muted-foreground">{index + 1}</span>
                            )}
                          </div>
                        </td>
                        <td className="py-3 px-4">
                          <div className="flex items-center">
                            <Avatar className="h-8 w-8 mr-2">
                              <AvatarImage src={player.avatar} alt={player.username} />
                              <AvatarFallback>{player.username[0]}</AvatarFallback>
                            </Avatar>
                            <span className="font-medium">{player.username}</span>
                          </div>
                        </td>
                        <td className="py-3 px-4 text-right font-medium">
                          {player.gamesPlayed.toLocaleString()} games
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
    </div>
  );
}
