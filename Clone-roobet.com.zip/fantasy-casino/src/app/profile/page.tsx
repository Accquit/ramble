"use client";

import { useEffect } from "react";
import { useRouter } from "next/navigation";
import { useUser } from "@/lib/user-context";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

export default function ProfilePage() {
  const { user, logout } = useUser();
  const router = useRouter();

  // Redirect to login if not logged in
  useEffect(() => {
    if (user && !user.isLoggedIn) {
      router.push("/auth/login");
    }
  }, [user, router]);

  if (!user || !user.isLoggedIn) {
    return <div className="container py-20 text-center">Loading...</div>;
  }

  const handleLogout = () => {
    logout();
    router.push("/");
  };

  return (
    <div className="container py-10">
      <div className="grid gap-6 md:grid-cols-3">
        {/* Sidebar with user info */}
        <Card className="casino-card md:col-span-1">
          <CardHeader className="flex flex-col items-center text-center">
            <Avatar className="h-24 w-24 mb-4">
              <AvatarImage src={user.avatar} alt={user.username} />
              <AvatarFallback className="text-2xl">{user.username.charAt(0).toUpperCase()}</AvatarFallback>
            </Avatar>
            <CardTitle className="text-xl">{user.username}</CardTitle>
            <CardDescription>
              Joined {user.joinedAt.toLocaleDateString()}
            </CardDescription>
          </CardHeader>
          <CardContent className="flex flex-col items-center space-y-4">
            <div className="flex items-center justify-center rounded-full bg-secondary px-4 py-2">
              <span className="mr-1 text-lg font-medium text-gold">{user.balance.toLocaleString()}</span>
              <span className="text-sm font-medium">coins</span>
            </div>
            <div className="w-full space-y-2 text-center">
              <div>
                <div className="text-sm text-muted-foreground">Games Played</div>
                <div className="text-lg font-semibold">{user.gamesPlayed}</div>
              </div>
              <div>
                <div className="text-sm text-muted-foreground">Total Winnings</div>
                <div className="text-lg font-semibold text-success">{user.winnings.toLocaleString()} coins</div>
              </div>
              <div>
                <div className="text-sm text-muted-foreground">Total Losses</div>
                <div className="text-lg font-semibold text-destructive">{user.losses.toLocaleString()} coins</div>
              </div>
            </div>
          </CardContent>
          <CardFooter>
            <Button onClick={handleLogout} variant="outline" className="w-full">
              Sign Out
            </Button>
          </CardFooter>
        </Card>

        {/* Main content area */}
        <div className="md:col-span-2 space-y-6">
          <Card className="casino-card">
            <CardHeader>
              <CardTitle>Game Stats</CardTitle>
              <CardDescription>Your gaming performance</CardDescription>
            </CardHeader>
            <CardContent>
              <Tabs defaultValue="history">
                <TabsList className="grid w-full grid-cols-3">
                  <TabsTrigger value="history">Game History</TabsTrigger>
                  <TabsTrigger value="achievements">Achievements</TabsTrigger>
                  <TabsTrigger value="rewards">Daily Rewards</TabsTrigger>
                </TabsList>
                <TabsContent value="history" className="mt-6">
                  {user.gamesPlayed > 0 ? (
                    <div className="rounded-md border">
                      <div className="p-4 text-center">
                        <p>Recent game history will appear here.</p>
                      </div>
                    </div>
                  ) : (
                    <div className="rounded-md border p-4 text-center">
                      <p>You haven't played any games yet!</p>
                      <Button asChild className="mt-4">
                        <a href="/games">Play Now</a>
                      </Button>
                    </div>
                  )}
                </TabsContent>
                <TabsContent value="achievements" className="mt-6">
                  <div className="rounded-md border p-4 text-center">
                    <p>Achievements will unlock as you play games.</p>
                    <div className="mt-4 grid gap-4 sm:grid-cols-2">
                      <div className="flex items-center space-x-4 rounded-md border p-4 opacity-50">
                        <div className="rounded-full bg-primary/20 p-2">🏆</div>
                        <div>
                          <h4 className="font-semibold">First Win</h4>
                          <p className="text-sm text-muted-foreground">Win your first game</p>
                        </div>
                      </div>
                      <div className="flex items-center space-x-4 rounded-md border p-4 opacity-50">
                        <div className="rounded-full bg-primary/20 p-2">💰</div>
                        <div>
                          <h4 className="font-semibold">High Roller</h4>
                          <p className="text-sm text-muted-foreground">Win 10,000 coins in a single game</p>
                        </div>
                      </div>
                    </div>
                  </div>
                </TabsContent>
                <TabsContent value="rewards" className="mt-6">
                  <div className="rounded-md border p-4">
                    <div className="text-center mb-4">
                      <h3 className="text-lg font-semibold">Daily Rewards</h3>
                      <p className="text-sm text-muted-foreground">Come back every day for free coins!</p>
                    </div>
                    <div className="flex justify-center">
                      <Button className="w-48">Claim 500 Coins</Button>
                    </div>
                  </div>
                </TabsContent>
              </Tabs>
            </CardContent>
          </Card>

          <Card className="casino-card">
            <CardHeader>
              <CardTitle>Settings</CardTitle>
              <CardDescription>Manage your account settings</CardDescription>
            </CardHeader>
            <CardContent>
              <p className="text-center">
                Account settings and preferences will be available in future updates.
              </p>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
