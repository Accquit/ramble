"use client";

import Link from "next/link";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { useUser } from "@/lib/user-context";
import { Wallet } from "lucide-react";

export default function HomePage() {
  const { user } = useUser();

  return (
    <div className="flex flex-col">
      {/* Hero Section */}
      <section className="casino-gradient relative overflow-hidden py-20 md:py-32">
        <div className="container relative z-10">
          <div className="flex flex-col items-center justify-center text-center">
            <h1 className="mb-4 text-4xl font-extrabold tracking-tight gold-text md:text-5xl lg:text-6xl">
              Fantasy Casino
            </h1>
            <p className="mb-6 max-w-[42rem] text-xl text-muted-foreground md:text-2xl">
              Experience the thrill of casino gaming with zero risk. Play with virtual currency and climb the leaderboards!
            </p>
            <div className="flex flex-col gap-4 sm:flex-row">
              <Button asChild size="lg" className="neon-border">
                <Link href="/games">Play Now</Link>
              </Button>
              {user?.isLoggedIn ? (
                <Button asChild size="lg" variant="outline">
                  <Link href="/dashboard" className="flex items-center">
                    <Wallet className="mr-2 h-4 w-4" />
                    Dashboard
                  </Link>
                </Button>
              ) : (
                <Button asChild size="lg" variant="outline">
                  <Link href="/auth/register">Create Account</Link>
                </Button>
              )}
            </div>
          </div>
        </div>

        {/* Background decoration elements */}
        <div className="absolute inset-0 overflow-hidden opacity-30">
          <div className="shine-effect absolute -inset-[10%] rotate-12 rounded-full"></div>
          <div className="absolute top-0 left-0 h-64 w-64 rounded-full bg-primary/20 blur-3xl"></div>
          <div className="absolute bottom-0 right-0 h-64 w-64 rounded-full bg-accent/20 blur-3xl"></div>
        </div>
      </section>

      {/* Featured Games Section */}
      <section className="py-16 md:py-24">
        <div className="container">
          <div className="mb-12 text-center">
            <h2 className="mb-2 text-3xl font-bold tracking-tight neon-text md:text-4xl">Featured Games</h2>
            <p className="text-muted-foreground">Try your luck on our most popular games</p>
          </div>

          <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {/* Slots Game Card */}
            <Card className="casino-card">
              <CardHeader>
                <CardTitle className="text-xl">Slot Machine</CardTitle>
                <CardDescription>Spin to win with our virtual slot machine</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="aspect-video rounded-md bg-muted/20 flex items-center justify-center">
                  <span className="text-4xl">🎰</span>
                </div>
              </CardContent>
              <CardFooter>
                <Button asChild className="w-full">
                  <Link href="/games/slots">Play Slots</Link>
                </Button>
              </CardFooter>
            </Card>

            {/* Dice Game Card */}
            <Card className="casino-card">
              <CardHeader>
                <CardTitle className="text-xl">Dice Roller</CardTitle>
                <CardDescription>Test your luck with dice games</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="aspect-video rounded-md bg-muted/20 flex items-center justify-center">
                  <span className="text-4xl">🎲</span>
                </div>
              </CardContent>
              <CardFooter>
                <Button asChild className="w-full">
                  <Link href="/games/dice">Play Dice</Link>
                </Button>
              </CardFooter>
            </Card>

            {/* Card Game Card */}
            <Card className="casino-card">
              <CardHeader>
                <CardTitle className="text-xl">Blackjack</CardTitle>
                <CardDescription>Play the classic card game</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="aspect-video rounded-md bg-muted/20 flex items-center justify-center">
                  <span className="text-4xl">🃏</span>
                </div>
              </CardContent>
              <CardFooter>
                <Button asChild className="w-full">
                  <Link href="/games/blackjack">Play Blackjack</Link>
                </Button>
              </CardFooter>
            </Card>
          </div>
        </div>
      </section>

      {/* How It Works Section */}
      <section className="bg-card py-16 md:py-24">
        <div className="container">
          <div className="mb-12 text-center">
            <h2 className="mb-2 text-3xl font-bold tracking-tight md:text-4xl">How It Works</h2>
            <p className="text-muted-foreground">Play, win, and climb the leaderboards with zero financial risk</p>
          </div>

          <div className="grid gap-8 md:grid-cols-3">
            <div className="flex flex-col items-center text-center">
              <div className="mb-4 flex h-16 w-16 items-center justify-center rounded-full bg-primary/10">
                <span className="text-2xl">1</span>
              </div>
              <h3 className="mb-2 text-xl font-medium">Create Account</h3>
              <p className="text-muted-foreground">Sign up for a free account and receive 10,000 virtual coins to start playing</p>
            </div>

            <div className="flex flex-col items-center text-center">
              <div className="mb-4 flex h-16 w-16 items-center justify-center rounded-full bg-primary/10">
                <span className="text-2xl">2</span>
              </div>
              <h3 className="mb-2 text-xl font-medium">Deposit/Play</h3>
              <p className="text-muted-foreground">Add more virtual coins through our dashboard and try your luck on various casino games</p>
            </div>

            <div className="flex flex-col items-center text-center">
              <div className="mb-4 flex h-16 w-16 items-center justify-center rounded-full bg-primary/10">
                <span className="text-2xl">3</span>
              </div>
              <h3 className="mb-2 text-xl font-medium">Win Big</h3>
              <p className="text-muted-foreground">Compete for the top spot on our leaderboards and unlock achievements</p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="casino-gradient py-16 md:py-24">
        <div className="container">
          <div className="flex flex-col items-center text-center">
            <h2 className="mb-4 text-3xl font-bold tracking-tight gold-text md:text-4xl">Ready to Play?</h2>
            <p className="mb-8 max-w-[42rem] text-xl text-muted-foreground">
              Join thousands of players enjoying risk-free casino gaming with Fantasy Casino!
            </p>
            <div className="flex flex-col gap-4 sm:flex-row">
              <Button asChild size="lg" className="neon-border">
                <Link href="/games">Start Playing Now</Link>
              </Button>
              {user?.isLoggedIn && (
                <Button asChild size="lg" variant="outline">
                  <Link href="/dashboard" className="flex items-center">
                    <Wallet className="mr-2 h-4 w-4" />
                    Deposit More Coins
                  </Link>
                </Button>
              )}
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
