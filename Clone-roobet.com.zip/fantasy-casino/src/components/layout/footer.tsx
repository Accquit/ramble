import Link from "next/link";

export function Footer() {
  return (
    <footer className="border-t bg-card">
      <div className="container flex flex-col gap-6 py-8 md:flex-row md:items-center md:justify-between md:py-12">
        <div className="flex flex-col gap-3">
          <Link href="/" className="flex items-center gap-2">
            <span className="text-xl font-bold gold-text">F</span>
            <span className="text-xl font-bold">Fantasy Casino</span>
          </Link>
          <p className="text-sm text-muted-foreground">
            Virtual gambling with fake currency. No real money involved.
          </p>
        </div>
        <div className="flex flex-col gap-2 sm:flex-row sm:items-center sm:gap-4">
          <nav className="flex gap-4 sm:gap-6">
            <Link
              href="/games"
              className="text-sm font-medium text-muted-foreground hover:text-foreground"
            >
              Games
            </Link>
            <Link
              href="/leaderboard"
              className="text-sm font-medium text-muted-foreground hover:text-foreground"
            >
              Leaderboard
            </Link>
            <Link
              href="/profile"
              className="text-sm font-medium text-muted-foreground hover:text-foreground"
            >
              Profile
            </Link>
          </nav>
        </div>
      </div>
      <div className="container border-t py-6">
        <div className="flex flex-col items-center justify-between gap-4 md:flex-row">
          <p className="text-xs text-muted-foreground text-center md:text-left">
            <strong>DISCLAIMER:</strong> This is a fantasy casino platform for entertainment purposes only.
            No real money transactions occur on this platform. All currency is virtual.
          </p>
          <p className="text-xs text-muted-foreground">
            &copy; {new Date().getFullYear()} Fantasy Casino. All rights reserved.
          </p>
        </div>
      </div>
    </footer>
  );
}
