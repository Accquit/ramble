"use client";

import Link from "next/link";
import { Button } from "@/components/ui/button";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import { Menu, Wallet, Crown } from "lucide-react";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { useUser } from "@/lib/user-context";
import { useVip } from "@/lib/vip-context";

export function Header() {
  const { user, logout } = useUser();
  const { currentTier } = useVip();

  return (
    <header className="sticky top-0 z-50 w-full border-b border-border/40 bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="container flex h-16 items-center">
        <div className="mr-4 flex">
          <Link href="/" className="mr-6 flex items-center space-x-2">
            <span className="text-2xl font-bold gold-text">F</span>
            <span className="hidden text-xl font-bold sm:inline-block">
              Fantasy Casino
            </span>
          </Link>
          <nav className="hidden md:flex md:items-center md:space-x-6">
            <Link
              href="/games"
              className="text-sm font-medium transition-colors hover:text-primary"
            >
              Games
            </Link>
            <Link
              href="/leaderboard"
              className="text-sm font-medium transition-colors hover:text-primary"
            >
              Leaderboard
            </Link>
            {user?.isLoggedIn && (
              <>
                <Link
                  href="/vip"
                  className="text-sm font-medium transition-colors hover:text-primary flex items-center"
                >
                  <Crown className={`h-4 w-4 mr-1 ${currentTier.colorClass}`} />
                  VIP
                  {currentTier.level > 0 && (
                    <span className={`ml-1 text-xs px-1.5 py-0.5 rounded-full ${currentTier.badgeClass}`}>
                      {currentTier.name}
                    </span>
                  )}
                </Link>
                <Link
                  href="/dashboard"
                  className="text-sm font-medium transition-colors hover:text-primary flex items-center"
                >
                  <Wallet className="h-4 w-4 mr-1" />
                  Dashboard
                </Link>
              </>
            )}
            <Link
              href="/profile"
              className="text-sm font-medium transition-colors hover:text-primary"
            >
              Profile
            </Link>
          </nav>
        </div>
        <div className="flex flex-1 items-center justify-end space-x-4">
          <div className="hidden md:flex md:items-center md:space-x-4">
            <div className="flex items-center rounded-full bg-secondary px-3 py-1">
              <span className="mr-1 text-xs font-medium text-gold">
                {user?.balance?.toLocaleString() || 0}
              </span>
              <span className="text-xs font-medium">coins</span>
            </div>

            {user?.isLoggedIn ? (
              <div className="flex items-center gap-4">
                <Button asChild variant="outline" size="sm" className="flex items-center gap-1">
                  <Link href="/dashboard">
                    <Wallet className="h-4 w-4" />
                    <span className="ml-1">Deposit</span>
                  </Link>
                </Button>

                <div className="flex items-center gap-2">
                  <div className="relative">
                    <Avatar className="h-8 w-8">
                      <AvatarImage src={user.avatar} alt={user.username} />
                      <AvatarFallback className="text-xs">{user.username.charAt(0).toUpperCase()}</AvatarFallback>
                    </Avatar>
                    {currentTier.level > 0 && (
                      <div className={`absolute -top-1 -right-1 h-3 w-3 rounded-full ${currentTier.colorClass}`}></div>
                    )}
                  </div>
                  <div className="flex items-center gap-4">
                    <Link
                      href="/profile"
                      className="text-sm font-medium hover:text-primary"
                    >
                      {user.username}
                      {currentTier.level > 0 && (
                        <span className={`ml-1.5 text-xs inline-flex items-center ${currentTier.colorClass}`}>
                          <Crown className="h-3 w-3 mr-0.5" />
                          {currentTier.name}
                        </span>
                      )}
                    </Link>
                    <Button variant="outline" size="sm" onClick={() => logout()}>
                      Sign Out
                    </Button>
                  </div>
                </div>
              </div>
            ) : (
              <nav className="flex items-center space-x-2">
                <Button variant="outline" asChild>
                  <Link href="/auth/login">Sign In</Link>
                </Button>
                <Button asChild>
                  <Link href="/auth/register">Sign Up</Link>
                </Button>
              </nav>
            )}
          </div>

          <Sheet>
            <SheetTrigger asChild>
              <Button variant="outline" size="icon" className="md:hidden">
                <Menu className="h-5 w-5" />
                <span className="sr-only">Toggle Menu</span>
              </Button>
            </SheetTrigger>
            <SheetContent side="right">
              <nav className="grid gap-6 text-lg font-medium">
                <Link
                  href="/"
                  className="flex items-center gap-2 text-lg font-semibold"
                >
                  <span className="text-xl font-bold gold-text">F</span>
                  Fantasy Casino
                </Link>

                {user?.isLoggedIn && (
                  <div className="flex flex-col items-center gap-2 mb-4">
                    <div className="relative">
                      <Avatar className="h-16 w-16">
                        <AvatarImage src={user.avatar} alt={user.username} />
                        <AvatarFallback>{user.username.charAt(0).toUpperCase()}</AvatarFallback>
                      </Avatar>
                      {currentTier.level > 0 && (
                        <div className={`absolute -top-1 -right-1 h-4 w-4 rounded-full ${currentTier.colorClass} flex items-center justify-center`}>
                          <Crown className="h-2.5 w-2.5" />
                        </div>
                      )}
                    </div>
                    <div className="text-center">
                      <div className="font-medium">{user.username}</div>
                      {currentTier.level > 0 && (
                        <div className={`text-xs ${currentTier.colorClass} flex items-center justify-center mb-1`}>
                          <Crown className="h-3 w-3 mr-0.5" />
                          {currentTier.name} VIP
                        </div>
                      )}
                      <div className="flex items-center justify-center rounded-full bg-secondary px-3 py-1 mt-1">
                        <span className="mr-1 text-xs font-medium text-gold">{user.balance.toLocaleString()}</span>
                        <span className="text-xs font-medium">coins</span>
                      </div>
                    </div>
                  </div>
                )}

                <Link
                  href="/games"
                  className="hover:text-primary"
                >
                  Games
                </Link>
                <Link
                  href="/leaderboard"
                  className="hover:text-primary"
                >
                  Leaderboard
                </Link>
                <Link
                  href="/profile"
                  className="hover:text-primary"
                >
                  Profile
                </Link>

                {user?.isLoggedIn && (
                  <>
                    <Link
                      href="/vip"
                      className="hover:text-primary flex items-center"
                    >
                      <Crown className={`h-4 w-4 mr-2 ${currentTier.colorClass}`} />
                      VIP Program
                    </Link>
                    <Link
                      href="/dashboard"
                      className="hover:text-primary flex items-center"
                    >
                      <Wallet className="h-4 w-4 mr-2" />
                      Dashboard
                    </Link>
                  </>
                )}

                {user?.isLoggedIn ? (
                  <>
                    <Button asChild variant="outline" className="justify-start">
                      <Link href="/dashboard">
                        <Wallet className="h-4 w-4 mr-2" />
                        Deposit/Withdraw
                      </Link>
                    </Button>
                    <Button onClick={() => logout()}>Sign Out</Button>
                  </>
                ) : (
                  <>
                    <Button asChild>
                      <Link href="/auth/login">Sign In</Link>
                    </Button>
                    <Button asChild variant="outline">
                      <Link href="/auth/register">Sign Up</Link>
                    </Button>
                  </>
                )}
              </nav>
            </SheetContent>
          </Sheet>
        </div>
      </div>
    </header>
  );
}
