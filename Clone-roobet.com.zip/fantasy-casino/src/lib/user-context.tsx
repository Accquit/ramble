"use client";

import { createContext, useContext, useState, useEffect } from "react";

type User = {
  id: string;
  username: string;
  balance: number;
  isLoggedIn: boolean;
  avatar?: string;
  gamesPlayed: number;
  winnings: number;
  losses: number;
  joinedAt: Date;
};

type UserContextType = {
  user: User | null;
  login: (username: string, password: string) => Promise<boolean>;
  register: (username: string, password: string) => Promise<boolean>;
  logout: () => void;
  updateBalance: (amount: number) => void;
  isLoading: boolean;
};

const defaultUser: User = {
  id: "guest",
  username: "Guest",
  balance: 1000,
  isLoggedIn: false,
  gamesPlayed: 0,
  winnings: 0,
  losses: 0,
  joinedAt: new Date(),
};

const UserContext = createContext<UserContextType | undefined>(undefined);

export function UserProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  // Simulate loading user from localStorage on client-side
  useEffect(() => {
    const storedUser = localStorage.getItem("fantasy-casino-user");

    if (storedUser) {
      try {
        setUser(JSON.parse(storedUser));
      } catch (e) {
        console.error("Failed to parse stored user", e);
        setUser(defaultUser);
      }
    } else {
      setUser(defaultUser);
    }

    setIsLoading(false);
  }, []);

  // Save user to localStorage when it changes
  useEffect(() => {
    if (user && !isLoading) {
      localStorage.setItem("fantasy-casino-user", JSON.stringify(user));
    }
  }, [user, isLoading]);

  // Mock authentication functions
  const login = async (username: string, password: string): Promise<boolean> => {
    setIsLoading(true);

    // In a real app, this would be an API call
    await new Promise(resolve => setTimeout(resolve, 1000));

    // Simple mock: accept any username/password for demo
    const loggedInUser: User = {
      id: `user_${Date.now()}`,
      username,
      balance: 5000, // Starting balance for new users
      isLoggedIn: true,
      avatar: undefined,
      gamesPlayed: 0,
      winnings: 0,
      losses: 0,
      joinedAt: new Date(),
    };

    setUser(loggedInUser);
    setIsLoading(false);
    return true;
  };

  const register = async (username: string, password: string): Promise<boolean> => {
    setIsLoading(true);

    // In a real app, this would be an API call
    await new Promise(resolve => setTimeout(resolve, 1000));

    // Simple mock: accept any registration for demo
    const newUser: User = {
      id: `user_${Date.now()}`,
      username,
      balance: 10000, // Bonus starting balance for new users
      isLoggedIn: true,
      avatar: undefined,
      gamesPlayed: 0,
      winnings: 0,
      losses: 0,
      joinedAt: new Date(),
    };

    setUser(newUser);
    setIsLoading(false);
    return true;
  };

  const logout = () => {
    setUser(defaultUser);
    localStorage.removeItem("fantasy-casino-user");
  };

  const updateBalance = (amount: number) => {
    if (user) {
      const newBalance = user.balance + amount;
      const winnings = amount > 0 ? user.winnings + amount : user.winnings;
      const losses = amount < 0 ? user.losses + Math.abs(amount) : user.losses;

      setUser({
        ...user,
        balance: newBalance,
        gamesPlayed: user.gamesPlayed + 1,
        winnings,
        losses,
      });
    }
  };

  return (
    <UserContext.Provider
      value={{
        user,
        login,
        register,
        logout,
        updateBalance,
        isLoading,
      }}
    >
      {children}
    </UserContext.Provider>
  );
}

export function useUser() {
  const context = useContext(UserContext);

  if (context === undefined) {
    throw new Error("useUser must be used within a UserProvider");
  }

  return context;
}
