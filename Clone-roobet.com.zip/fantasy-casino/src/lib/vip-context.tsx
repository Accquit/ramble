"use client";

import { createContext, useContext, useState, useEffect } from "react";
import { useUser } from "@/lib/user-context";

// VIP tiers with their benefits
export const VIP_TIERS = {
  NONE: {
    name: "Standard",
    level: 0,
    colorClass: "text-muted-foreground",
    badgeClass: "bg-muted text-muted-foreground",
    requiredWager: 0,
    depositBonus: 0,
    rakeback: 0,
    weeklyBonus: 0,
    appearingOddsBoost: 0, // This appears to boost odds but doesn't really
    actualOddsBoost: 0, // The actual odds boost (always 0)
    unlockMessage: "Standard account",
    description: "Basic casino access"
  },
  BRONZE: {
    name: "Bronze",
    level: 1,
    colorClass: "text-amber-700",
    badgeClass: "bg-amber-700/20 text-amber-700",
    requiredWager: 5000,
    depositBonus: 5,
    rakeback: 2,
    weeklyBonus: 100,
    appearingOddsBoost: 2, // 2% appearing boost
    actualOddsBoost: 0,
    unlockMessage: "Bronze VIP unlocked!",
    description: "Enhanced gaming experience"
  },
  SILVER: {
    name: "Silver",
    level: 2,
    colorClass: "text-slate-400",
    badgeClass: "bg-slate-400/20 text-slate-400",
    requiredWager: 15000,
    depositBonus: 10,
    rakeback: 5,
    weeklyBonus: 500,
    appearingOddsBoost: 5, // 5% appearing boost
    actualOddsBoost: 0,
    unlockMessage: "Silver VIP unlocked!",
    description: "Improved odds and rewards"
  },
  GOLD: {
    name: "Gold",
    level: 3,
    colorClass: "text-gold",
    badgeClass: "bg-amber-400/20 text-gold",
    requiredWager: 50000,
    depositBonus: 15,
    rakeback: 7,
    weeklyBonus: 1000,
    appearingOddsBoost: 7, // 7% appearing boost
    actualOddsBoost: 0,
    unlockMessage: "Gold VIP unlocked!",
    description: "Premium benefits and priority service"
  },
  PLATINUM: {
    name: "Platinum",
    level: 4,
    colorClass: "text-primary",
    badgeClass: "bg-primary/20 text-primary",
    requiredWager: 100000,
    depositBonus: 20,
    rakeback: 10,
    weeklyBonus: 2500,
    appearingOddsBoost: 10, // 10% appearing boost
    actualOddsBoost: 0,
    unlockMessage: "Platinum VIP unlocked!",
    description: "Exclusive benefits and personalized service"
  },
  DIAMOND: {
    name: "Diamond",
    level: 5,
    colorClass: "text-blue-400",
    badgeClass: "bg-blue-400/20 text-blue-400",
    requiredWager: 250000,
    depositBonus: 25,
    rakeback: 15,
    weeklyBonus: 5000,
    appearingOddsBoost: 15, // 15% appearing boost
    actualOddsBoost: 0,
    unlockMessage: "Diamond VIP unlocked!",
    description: "Elite status with maximum benefits"
  }
};

export type VipTierKey = keyof typeof VIP_TIERS;
export type VipTier = typeof VIP_TIERS[VipTierKey];

type VipContextType = {
  currentTier: VipTier;
  nextTier: VipTier | null;
  progress: number; // Progress to next tier (0-100)
  totalWagered: number;
  claimWeeklyBonus: () => void;
  lastWeeklyBonusClaimed: Date | null;
  canClaimWeeklyBonus: boolean;
  checkVipTierProgress: () => void;
};

const VipContext = createContext<VipContextType | undefined>(undefined);

export function VipProvider({ children }: { children: React.ReactNode }) {
  const { user, updateBalance } = useUser();
  const [currentTier, setCurrentTier] = useState<VipTier>(VIP_TIERS.NONE);
  const [nextTier, setNextTier] = useState<VipTier | null>(VIP_TIERS.BRONZE);
  const [progress, setProgress] = useState<number>(0);
  const [totalWagered, setTotalWagered] = useState<number>(0);
  const [lastWeeklyBonusClaimed, setLastWeeklyBonusClaimed] = useState<Date | null>(null);
  const [canClaimWeeklyBonus, setCanClaimWeeklyBonus] = useState<boolean>(false);

  // Load VIP data from localStorage
  useEffect(() => {
    if (typeof window !== 'undefined') {
      const storedVipData = localStorage.getItem('fantasy-casino-vip');
      if (storedVipData) {
        try {
          const parsedData = JSON.parse(storedVipData);
          setTotalWagered(parsedData.totalWagered || 0);

          if (parsedData.lastWeeklyBonusClaimed) {
            setLastWeeklyBonusClaimed(new Date(parsedData.lastWeeklyBonusClaimed));
          }

          // Update VIP tier based on stored data
          checkVipTierProgress(parsedData.totalWagered || 0);
        } catch (e) {
          console.error('Failed to parse stored VIP data', e);
        }
      }
    }
  }, []);

  // Update localStorage when VIP data changes
  useEffect(() => {
    if (typeof window !== 'undefined' && user?.isLoggedIn) {
      localStorage.setItem('fantasy-casino-vip', JSON.stringify({
        totalWagered,
        lastWeeklyBonusClaimed: lastWeeklyBonusClaimed?.toISOString() || null
      }));
    }
  }, [totalWagered, lastWeeklyBonusClaimed, user]);

  // Check if weekly bonus can be claimed
  useEffect(() => {
    if (!lastWeeklyBonusClaimed) {
      setCanClaimWeeklyBonus(currentTier.level > 0);
      return;
    }

    const now = new Date();
    const lastClaimed = new Date(lastWeeklyBonusClaimed);

    // Check if 7 days have passed since last claim
    const daysSinceLastClaim = Math.floor((now.getTime() - lastClaimed.getTime()) / (1000 * 60 * 60 * 24));
    setCanClaimWeeklyBonus(daysSinceLastClaim >= 7 && currentTier.level > 0);
  }, [lastWeeklyBonusClaimed, currentTier]);

  // Update total wagered when user plays games
  useEffect(() => {
    if (user) {
      const userTotalWagered = user.winnings + user.losses;
      if (userTotalWagered !== totalWagered) {
        setTotalWagered(userTotalWagered);
        checkVipTierProgress(userTotalWagered);
      }
    }
  }, [user]);

  // Check and update VIP tier based on total wagered
  const checkVipTierProgress = (wagerAmount = totalWagered) => {
    // Determine current tier
    let current = VIP_TIERS.NONE;
    let next: VipTier | null = null;

    if (wagerAmount >= VIP_TIERS.DIAMOND.requiredWager) {
      current = VIP_TIERS.DIAMOND;
      next = null;
    } else if (wagerAmount >= VIP_TIERS.PLATINUM.requiredWager) {
      current = VIP_TIERS.PLATINUM;
      next = VIP_TIERS.DIAMOND;
    } else if (wagerAmount >= VIP_TIERS.GOLD.requiredWager) {
      current = VIP_TIERS.GOLD;
      next = VIP_TIERS.PLATINUM;
    } else if (wagerAmount >= VIP_TIERS.SILVER.requiredWager) {
      current = VIP_TIERS.SILVER;
      next = VIP_TIERS.GOLD;
    } else if (wagerAmount >= VIP_TIERS.BRONZE.requiredWager) {
      current = VIP_TIERS.BRONZE;
      next = VIP_TIERS.SILVER;
    } else {
      current = VIP_TIERS.NONE;
      next = VIP_TIERS.BRONZE;
    }

    setCurrentTier(current);
    setNextTier(next);

    // Calculate progress to next tier
    if (next) {
      const currentMin = current.requiredWager;
      const nextMin = next.requiredWager;
      const progressPercent = ((wagerAmount - currentMin) / (nextMin - currentMin)) * 100;
      setProgress(Math.min(Math.max(progressPercent, 0), 100));
    } else {
      setProgress(100); // At max tier
    }
  };

  // Claim weekly bonus
  const claimWeeklyBonus = () => {
    if (!canClaimWeeklyBonus || !user || currentTier.level === 0) {
      return;
    }

    const bonusAmount = currentTier.weeklyBonus;
    updateBalance(bonusAmount);
    setLastWeeklyBonusClaimed(new Date());
    setCanClaimWeeklyBonus(false);
  };

  return (
    <VipContext.Provider
      value={{
        currentTier,
        nextTier,
        progress,
        totalWagered,
        claimWeeklyBonus,
        lastWeeklyBonusClaimed,
        canClaimWeeklyBonus,
        checkVipTierProgress
      }}
    >
      {children}
    </VipContext.Provider>
  );
}

export function useVip() {
  const context = useContext(VipContext);

  if (context === undefined) {
    throw new Error("useVip must be used within a VipProvider");
  }

  return context;
}
